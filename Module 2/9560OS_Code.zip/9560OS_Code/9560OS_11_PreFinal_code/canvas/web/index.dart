library canvas;

import 'dart:html';
import 'dart:math';
import 'dart:async';

part 'widgets/tool_selector_widget.dart';
part 'widgets/color_selector_widget.dart';
part 'widgets/canvas_widget.dart';

part 'tools/tool.dart';
part 'tools/pen.dart';
part 'tools/rectangle.dart';
part 'tools/line.dart';
part 'tools/oval.dart';

// Calculate absolute value of number
num abs(num value) => value < 0 ? -value : value;

// Return offset of mouse pointer from any mouse event
Point offset(MouseEvent event) => event.offset;

void main() {
  // Create an instance of [CanvasWidget]
  CanvasWidget canvas = new CanvasWidget(".view-canvas", ".draw-canvas");
  // Create an instance of [BrushSelectorWidget]
  ToolSelectorWidget tools = new ToolSelectorWidget(".tool-selector")
  ..onToolSelected.pipe(canvas);
  // Create and add tools to [ShapeSelectorWidget]
  tools.addTool(new Pen());
  tools.addTool(new Rectangle(), select:true);
  tools.addTool(new Line());
  tools.addTool(new Oval());
  // Create a stroke color selector
  new ColorSelectorWidget(".stroke_color_selector", ColorSelectedEvent.STROKE_COLOR, 'black')
  ..onColorSelected.pipe(canvas);
  // Create a fill color selector
  new ColorSelectorWidget(".fill_color_selector", ColorSelectedEvent.FILL_COLOR, 'aqua')
  ..onColorSelected.pipe(canvas);
  // Register a clear button listener
  querySelector(".clear-btn").onClick.listen((MouseEvent event) {
   canvas.clear();
  });
  // Register a preview button listener
  querySelector(".preview-btn").onClick.listen((MouseEvent event) {
   event.preventDefault();
   window.open(canvas.viewCanvas.toDataUrl("image/png"), "Image Preview");
  });
}