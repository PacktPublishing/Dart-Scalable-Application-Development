part of canvas;

/**
 * Simple pen tool
 */
class Pen extends Tool {
  
  String get name => "Pen";
  
  @override
  void beginDraw(CanvasRenderingContext2D context, Point point) {
    super.beginDraw(context, point);
    context.beginPath();
    context.moveTo(startPoint.x, startPoint.y);
  }
  
  @override
  void drawing(CanvasRenderingContext2D context, Point point) {
    if (isDrawing) {
      context.lineTo(point.x, point.y);
      context.stroke();
    }
  }
}
