part of canvas;

/**
 * Line tool uses to create lines.
 */
class Line extends Tool {
  
  String get name => "Line";
  
  @override
  void drawing(CanvasRenderingContext2D context, Point point) {
    if (isDrawing) {
      context.clearRect(0, 0, context.canvas.width, context.canvas.height);
      context.beginPath();

      context.moveTo(startPoint.x, startPoint.y);
      context.lineTo(point.x, point.y);
      
      context.stroke();
      context.closePath();
    }
  }
}
