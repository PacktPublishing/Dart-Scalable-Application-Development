part of canvas;

/**
 * This tool transforms a drawing context into a rectangle
 * enclosing the oval and use arc method to draw it.
 */
class Oval extends Tool {
  
  String get name => "Oval";
  
  @override
  void drawing(CanvasRenderingContext2D context, Point point) {
    if (isDrawing) {
      context.save();
      context.clearRect(0, 0, context.canvas.width, context.canvas.height);
      context.beginPath();
      
      var rx = (point.x - startPoint.x) / 2;
      var ry = (point.y - startPoint.y) / 2;
      context.translate(startPoint.x + rx, startPoint.y + ry);
      
      rx = abs(rx);
      ry = abs(ry);
      if (rx < ry)
      {
          context.scale(1, abs(ry / rx));
          context.arc(1, 1, rx, 0, 2 * PI, false);
      }
      else
      {
          context.scale(abs(rx / ry), 1);
          context.arc(1, 1, ry, 0, 2 * PI, false);
      }
      
      context.stroke();
      context.restore();
    }
  }
}
