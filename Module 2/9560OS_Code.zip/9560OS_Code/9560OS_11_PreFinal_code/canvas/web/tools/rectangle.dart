part of canvas;

/**
 * Rectangle tool
 */
class Rectangle extends Tool {
  
  String get name => "Rectangle";
  
  @override
  void drawing(CanvasRenderingContext2D context, Point point) {
    if (isDrawing) {
      context.clearRect(0, 0, context.canvas.width, context.canvas.height);
      
      int x = min(point.x, startPoint.x).round(),
          y = min(point.y, startPoint.y).round(),
          w = abs(point.x - startPoint.x).round(),
          h = abs(point.y - startPoint.y).round();

      context.fillRect(x, y, w, h);
      context.strokeRect(x, y, w, h);
    }
  }
}
