part of canvas;

/**
 * Abstract class defines common behaviour and properties for all tools.
 */
abstract class Tool {
  bool isDrawing = false;
  Point startPoint;
  
  String get name;
  
  void beginDraw(CanvasRenderingContext2D context, Point point) {
    isDrawing = true;
    startPoint = point;
  }
  
  void drawing(CanvasRenderingContext2D context, Point point);
  
  void finishDraw(CanvasRenderingContext2D context, Point point) {
    if (isDrawing) {
      drawing(context, point);
      isDrawing = false;
    }
  }
}