part of canvas;

/**
 * Canvas widget listens mouse events from [CanvasElement] to draw 
 * with selected tool.
 */
class CanvasWidget implements StreamConsumer {

  CanvasElement _viewCanvas, _drawCanvas;
  
  CanvasElement get viewCanvas => _viewCanvas;
  CanvasElement get drawCanvas => _drawCanvas;
  CanvasRenderingContext2D get context => _viewCanvas.context2D;
  CanvasRenderingContext2D get drawContext => _drawCanvas.context2D;
  
  Tool _tool;
  
  /**
   * Create a instance of CanvasWidget. The [viewCanvasSelector] and 
   * [drawCanvasSelector] need to find CanvasElement's.
   */
  CanvasWidget(String viewCanvasSelector, String drawCanvasSelector) {
    // Find canvas elements
    _viewCanvas = querySelector(viewCanvasSelector);
    _drawCanvas = querySelector(drawCanvasSelector);
    // Add mouse event listeners
    _drawCanvas.onMouseDown.listen((evt) => _tool.beginDraw(drawContext, offset(evt)));
    _drawCanvas.onMouseMove.listen((evt) => _tool.drawing(drawContext, offset(evt)));
    
    var _finishDraw = (evt) {
      _tool.finishDraw(drawContext, offset(evt));
      copyContext();
    };
    
    _drawCanvas.onMouseUp.listen(_finishDraw);
    _drawCanvas.onMouseLeave.listen(_finishDraw);
  }

  /**
   * Copy drawn image from draw canvas into view context. 
   * After all it clears the draw canvas.
   */
  copyContext() {
    context.drawImage(_drawCanvas, 0, 0);
    _drawCanvas.context2D.clearRect(0, 0, _drawCanvas.width, _drawCanvas.height);
  }
  
  /**
   * Clear the view canvas
   */
  clear() {
    context.clearRect(0,  0, _viewCanvas.width, _viewCanvas.height);
  }
  
  /**
   * Consumes the elements of [stream].
   * Listens on [stream] and does something for each event.
   */
  Future addStream(Stream stream) {
    return stream.listen((event) {
      if (event is ColorSelectedEvent) {
        if (event.type == ColorSelectedEvent.STROKE_COLOR) {
            drawContext.strokeStyle = event.value;
        } else {
            drawContext.fillStyle = event.value;
        }
      } else if (event is ToolSelectedEvent) {
        _tool = event.tool;
      }
    }).asFuture();
  }

  /**
   * Tell the consumer that no futher streams will be added.
   *
   * Returns a future that is completed when the consumer is done handling
   * events.
   */
  Future close() {
    return new Future.value(null);
  }
}