part of canvas;

/**
 * Widget helps set selected tool in camvas via [ToolSelectedEvent].
 */
class ToolSelectorWidget {
  SelectElement _selectElement;
  Tool selectedTool;
  Map<String, Tool> _tools = new Map<String, Tool>();

  Iterable<String> get toolsNames => _tools.keys;

  StreamController<ToolSelectedEvent> _toolSelectedController =
      new StreamController<ToolSelectedEvent>();
  Stream<ToolSelectedEvent> get onToolSelected =>
      _toolSelectedController.stream;

  ToolSelectorWidget(String selector) {
    _selectElement = querySelector(selector);
    _selectElement.onChange.listen((Event event) {
      selectTool(_selectElement.value);
    });
  }

  void addTool(Tool tool, {bool select: false}) {
    _tools[tool.name] = tool;
    OptionElement item = new OptionElement(data: tool.name, value: tool.name);
    _selectElement.append(item);
    if (select) {
      selectTool(tool.name);
    }
  }

  Tool getTool(String name) {
    if (_tools.containsKey(name)) {
      return _tools[name];
    }
    throw new Exception("Brush with $name not found");
  }

  selectTool(String name) {
    selectedTool = getTool(name);
    _toolSelectedController.add(new ToolSelectedEvent(selectedTool));
    _selectElement.value = selectedTool.name;
  }

}

/**
 * Tool selected event uses to deliver selected tool into [CanvasWidget].
 */
class ToolSelectedEvent {

  final Tool tool;

  ToolSelectedEvent(this.tool);
}
