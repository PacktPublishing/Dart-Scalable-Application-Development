part of canvas;

/**
 * This widget creates pallete of colors. User choose color to draw with a tool. 
 * Port of bootstrap-colorselector. 
 * URL: https://github.com/flaute/bootstrap-colorselector
 */
class ColorSelectorWidget {
  SelectElement _select;
  Element _selector;
  final String colorStyle;
  
  StreamController<ColorSelectedEvent> _colorSelectedController = new StreamController<ColorSelectedEvent>();
  Stream<ColorSelectedEvent> get onColorSelected => _colorSelectedController.stream;
  
  ColorSelectorWidget(String selector, this.colorStyle, String initColor) {
    _select = querySelector(selector);
    
    var selectValue = _select.value;
    var selectedOptionElement = _select.querySelector("option[selected]");
    var selectColor = selectedOptionElement == null ? initColor : selectedOptionElement.dataset["color"];
    
    var markupUl = new UListElement()..classes.add("dropdown-menu dropdown-caret"); 
    var markupDiv = new DivElement()..classes.add("dropdown dropdown-colorselector"); 
    var markupSpan = new SpanElement()..classes.add("btn-colorselector")..style.backgroundColor = selectColor;
    var markupA = new AnchorElement(href: "#")..dataset["toggle"] = "dropdown"..classes.add("dropdown-toggle")..append(markupSpan);
    
    _select.options.forEach((OptionElement option) {
      var value = option.value;
      var color = option.dataset["color"];
      var title = option.text;

      // 
      var markupA = new AnchorElement(href: "#")..classes.add("color-btn");
      if (option.selected || selectValue == color) {
        markupA.classes.add("selected");
      }
      markupA.style.backgroundColor = color;
      markupA.dataset["color"] = color;
      markupA.dataset["value"] = value;
      markupA.title = title;

      // create li-tag
      markupUl.append(new LIElement()..append(markupA));
    });
    
    // append the colorselector
    markupDiv.append(markupA);
    // append the colorselector-dropdown
    markupDiv.append(markupUl);
    
    // hide the select
    _select.style.display = "none";
    
    // insert the colorselector
    _selector = _select.parent.append(markupDiv);
    
    // register change handler
    _select.onChange.listen((_) {
      var value = _select.value;
      var color = _select.querySelector("option[value='" + value + "']").dataset["color"];
      var title = _select.querySelector("option[value='" + value + "']").text;
      
      // remove old and set new selected color
      _select.nextElementSibling.querySelectorAll("li > .selected").forEach((Element el) => el.classes.remove("selected"));
      _select.nextElementSibling.querySelectorAll("ul > li > a[data-color='" + color + "']").forEach((Element el) => el.classes.add("selected"));
      
      _select.nextElementSibling.querySelector(".btn-colorselector").style.backgroundColor = color;
       
      _colorSelectedController.add(new ColorSelectedEvent(colorStyle, value, color, title));
    });
    
    // register click handler
    markupUl.onClick.listen((MouseEvent e) {
      var a = e.target as Element;

      if (a.classes.contains("color-btn")) {
        _select.value = a.dataset["value"];
        _select.dispatchEvent(new Event('change'));
  
        e.preventDefault();
        return true;
      }
      return false;
    });
    
    // Initialise widget with color
    setColor(initColor);
  }
  
  setColor(color) {
    // find value for color
    var value = _selector.querySelector("li > a[data-color='" + color + "']").dataset["value"];
    setValue(value);
  }
  
  setValue(value) {
    _select.value = value;
    _select.dispatchEvent(new Event('change'));
  }
}

class ColorSelectedEvent {
  static const String FILL_COLOR = "fill_color";
  static const String STROKE_COLOR = "stroke_color";
  
  final String type;
  final String value;
  final String color;
  final String title;
  
  ColorSelectedEvent(this.type, this.value, this.color, this.title);
}