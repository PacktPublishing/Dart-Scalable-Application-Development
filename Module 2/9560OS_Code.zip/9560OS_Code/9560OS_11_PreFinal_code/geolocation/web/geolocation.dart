import 'dart:html';
import 'package:google_maps/google_maps.dart';

void main() {
  final mapOptions = new MapOptions()
  ..zoom = 15
  ..mapTypeId = MapTypeId.ROADMAP;
  final map = new GMap(querySelector("#map_canvas"), mapOptions);
  
  window.navigator.geolocation.getCurrentPosition()
  .then((Geoposition geoposition) {
    Coordinates coords = geoposition.coords;
    querySelector("#latitude").text = coords.latitude
     .toStringAsPrecision(6);
    querySelector("#longitude").text = coords.longitude
     .toStringAsPrecision(6);
    //
    map.center = new LatLng(coords.latitude, coords.longitude);
  }, onError: (PositionError error){
    print(error.message);
  });
  
  window.navigator.geolocation.watchPosition(enableHighAccuracy:true)
  .listen((Geoposition geoposition) {
    Coordinates coords = geoposition.coords;
    map.center = new LatLng(coords.latitude, coords.longitude);
    //
    querySelector("#location_tracker").append(new DivElement()
    ..text = coords.latitude.toStringAsPrecision(6) + " x " + 
      coords.longitude.toStringAsPrecision(6));
  }, onError: (PositionError error){
      print(error.message);
  });
}