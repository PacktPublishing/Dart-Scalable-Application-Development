import 'dart:html';

void main() {
  var dragTarget = querySelector("#sample_drag_id")
  ..draggable = true
  ..onDragStart.listen((MouseEvent event) {
    event.dataTransfer.setData("text/plain", "I'm draggable");
    event.dataTransfer.setData("text/data", "1234");
    event.dataTransfer.setDragImage(new 
          ImageElement(src:'notification.png'), 0, 0);
    event.dataTransfer.effectAllowed = 'copy';
  });

  var dropTarget = querySelector("#sample_drop_id")
  ..onDragOver.listen((MouseEvent event) {
    if (checkTarget(event.target) && 
        checkTypes(event.dataTransfer.types)) {
      event.preventDefault();
      event.dataTransfer.dropEffect = 'copy';
    }
  })
  ..onDrop.listen((MouseEvent event) {
    Element dropTarget = event.target;
    dropTarget.innerHtml = event.dataTransfer.getData('text/plain');
    event.preventDefault();
  });
}

bool checkTarget(Element target) {
  return target.attributes.containsKey('droppable');
}

bool checkTypes(List<String> types) {
  return types.contains("text/data");
}