import 'dart:html';
import 'dart:async';

void main() {
  var notifyBtn = querySelector("#notify_btn")
  ..onClick.listen((Event event) {
    sendNotification();
  });
}

void sendNotification() {
  Notification.requestPermission().then((String permission) {
    if (permission == "granted") {
      Notification notification = 
        new Notification('My Notification', body: "Hello World",
          tag: "myNotification");
      notification.onShow.listen((Event event) {
        new Timer(new Duration(seconds:2), () {
          notification.close();
        });
      });
    }
  });
}