library storage_manager;

import 'dart:html';
import 'dart:async';
import 'dart:indexed_db';

import 'cookie.dart';

abstract class StorageManager {
  factory StorageManager() {
    if (IndexedDBStorageManager.supported) {
      return new IndexedDBStorageManager();
    } else if (WebStorageManager.supported) {
      return new WebStorageManager();
    } else {
      return new CookieStorageManager();
    }
  }
  
  Future<String> getItem(key);
  Future setItem(key, value);
  Future removeItem(key);
}

class CookieStorageManager implements StorageManager {
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return getCookie(key);
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      setCookie(key, value, 365);
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      removeCookie(key);
    });
  }
}

class WebStorageManager implements StorageManager {
  
  static bool get supported {
    if (window.localStorage != null) {
      try{
        window.localStorage["__name__"] = "__test__";
        window.localStorage.remove("__name__");
        return true;
      } catch(e) {
        return false;
      }
    } else {
      return false;
    }
  }
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return window.localStorage[key];
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      window.localStorage[key] = value;
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      window.localStorage.remove(key);
    });
  }
}

class IndexedDBStorageManager implements StorageManager {
  
  Database _database;
  
  static const SHOPPING = "SHOPPING";
  static const PRODUCT = "PRODUCT";
  static const TRANS_MODE = "readwrite";
  
  static bool get supported => IdbFactory.supported;
  
  Future _getDatabase(String dbName, String storeName) {
    if (_database == null) {
      return window.indexedDB.open(dbName).then((Database d) {
        _database = d;
        if (!_database.objectStoreNames.contains(storeName)) {
          _database.close();
          return window.indexedDB.open(dbName, 
              version: (d.version as int) + 1, 
              onUpgradeNeeded: (e) {
            Database d = e.target.result;
            d.createObjectStore(storeName);
          }).then((Database d) {
            _database = d;
            return _database;
          });
        }
        return _database;
      });
    } else {
      return new Future.sync(() => _database);
    }
  }
  
  Future<ObjectStore> startTransaction(String storeName) {
    return _getDatabase(SHOPPING, PRODUCT).then((Database database) {
      Transaction transaction = _database.transactionStore(storeName, TRANS_MODE);
      return transaction.objectStore(storeName);
    });
  }
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return startTransaction(PRODUCT).then((ObjectStore store) {
        return store.getObject(key);
      });
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      return startTransaction(PRODUCT).then((ObjectStore store) {
        return store.put(value, key);
      });
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      return startTransaction(PRODUCT).then((ObjectStore store) {
        return store.delete(key);
      });
    });
  }
}