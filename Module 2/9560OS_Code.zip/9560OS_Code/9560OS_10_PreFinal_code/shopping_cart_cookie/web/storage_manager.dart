library storage_manager;

import 'dart:async';

import 'cookie.dart';

abstract class StorageManager {
  factory StorageManager() {
    return new CookieStorageManager();
  }
  
  Future<String> getItem(key);
  Future setItem(key, value);
  Future removeItem(key);
}

class CookieStorageManager implements StorageManager {
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return getCookie(key);
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      setCookie(key, value, 365);
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      removeCookie(key);
    });
  }
}