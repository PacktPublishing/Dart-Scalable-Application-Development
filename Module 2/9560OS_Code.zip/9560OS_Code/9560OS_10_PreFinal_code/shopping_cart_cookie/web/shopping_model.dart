library shopping_service;

import 'dart:html';
import 'dart:async';
import 'dart:convert';

import 'product.dart';

class ShoppingModel {
  
  Future<List<Product>> getProducts() {
    return HttpRequest.getString("product.json").then((String data) {
      List<Product> result = [];
      JSON.decode(data).forEach((Map json) {
        result.add(new Product.fromJson(json));
      });
      return result;
    });
  }
}