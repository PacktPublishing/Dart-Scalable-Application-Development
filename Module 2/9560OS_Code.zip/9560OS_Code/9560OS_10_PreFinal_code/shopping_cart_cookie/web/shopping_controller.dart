library shopping_cart;

import 'dart:html';
import 'dart:async';

import 'product.dart';
import 'shopping_model.dart';
import 'storage_manager.dart';

class ShoppingController {
  final ShoppingModel model;
  final TableSectionElement tBody;
  final TableCellElement totalAmount;
  final StorageManager storage;
  
  List<Product> _products;
  
  ShoppingController(this.tBody, this.totalAmount, this.model, this.storage) {
    model.getProducts().then((List<Product> products) {
      _products = products;
      _init();
    });
  }

  _init() {
    update().then((value) {
      draw();
      drawTotal();
    });
  }
  
  Future update() {
    return Future.forEach(_products, (Product product) {
      // Read quantity of product from cookie
      return readQuantity(product);
    });
  }
  
  void draw() {
    // Clear all
    tBody.children.clear();
    _products.forEach((Product product) {
      drawItem(product);
    });
  }
  
  void drawItem(Product product) {
    var quantity, amount;
    var updateAmount = (Product product) {
        amount.text = product.amount.toString();
    };
    var updateQuantity = (Product product, int value) {
      product.quantity = value;
      saveQuantity(product);
      updateAmount(product);
      drawTotal();
    };
    TableRowElement row = tBody.addRow();
    row.addCell()..text = product.description;
    quantity = new NumberInputElement()
    ..min = '0'
    ..max = '9999'
    ..value = product.quantity.toString()
    ..onKeyUp.listen((Event event) {
      var value = int.parse(quantity.value.length > 0 ? quantity.value : '0');
      if (value < 0) {
        quantity.value = "0";
        value = 0;
      }
      updateQuantity(product, value);
    });
    row.addCell()..append(quantity);
    row.addCell()
    ..text = product.price.toString()
    ..classes.add("number");
    amount = new SpanElement();
    updateAmount(product);
    row.addCell()
    ..append(amount)
    ..classes.add("number");
  }
  
  void drawTotal() {
    var amount = 0.0;
    _products.forEach((Product product) {
      amount += product.amount;
    });
    totalAmount.text = amount.toString();
  }
  
  Future readQuantity(Product product) {
    return storage.getItem(Product.toCookieName(product)).then((String quantity) {
      if (quantity != null && quantity.length > 0) {
        product.quantity = int.parse(quantity);
      } else {
        product.quantity = 0;
      }
    });
  }
  
  saveQuantity(Product product) {
    if (product.quantity == 0) {
      storage.removeItem(Product.toCookieName(product));
    } else {
      storage.setItem(Product.toCookieName(product), product.quantity.toString());
    }
  }
  
  checkOut() {
    List<Product> selected = _selected;
    StringBuffer result = new StringBuffer();
    if (selected.length > 0) {
      double amount = 0.0;
      result.writeln("You ordered:");
      selected.forEach((Product product) {
        result.writeln(product.toString());
        amount += product.amount;
        // removeItem(Product.toCookieName(product));
        storage.removeItem(Product.toCookieName(product));
      });
      result.writeln("Total price is $amount \$USD");
      _init();
    } else {
      result.write("Please select products to bye");
    }
    window.alert(result.toString());
  }
  
  List<Product> get _selected => 
      _products.where((Product product) => product.quantity > 0).toList();
}