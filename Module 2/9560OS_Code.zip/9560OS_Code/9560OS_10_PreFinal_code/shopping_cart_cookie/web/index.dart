import 'dart:html';

import 'shopping_model.dart';
import 'shopping_controller.dart';
import 'storage_manager.dart';

void main() {
  StorageManager storage = new StorageManager();
  
  final ShoppingModel model = new ShoppingModel();
  final TableSectionElement tBody = querySelector("#shopping_items");
  final TableCellElement totalAmount = querySelector("#total_amount");
  final ButtonInputElement checkOut = querySelector("#check_out");

  final ShoppingController cart = new ShoppingController(tBody, totalAmount, model, storage);
  
  checkOut.onClick.listen((Event event){
    cart.checkOut();
  });
}
