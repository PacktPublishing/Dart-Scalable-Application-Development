library product;

class Product {
  static final NAME = 'PRODUCT_';
  
  String id;
  String description;
  num price = 0.0;
  
  int quantity = 0;
  num get amount => price * quantity;
  
  Product();
  
  factory Product.fromJson(Map json) {
    Product product = new Product()
    ..id = json["id"]
    ..description = json["description"]
    ..price = json["price"];
    return product;
  }
  
  static String toCookieName(Product product) {
    return Product.NAME + product.id;
  }
  
  static String fromCookieName(String cookie) {
    if (cookie.startsWith(NAME)) {
      return cookie.substring(NAME.length + 1);
    } else {
      return null;
    }
  }
  
  String toString() {
    return "$description x $quantity: $amount USD";
  }
}
