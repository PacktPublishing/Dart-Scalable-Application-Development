library cookie;

import 'dart:html';
import 'package:intl/intl.dart';

// Number milliseconds in one day
var theDay = 24*60*60*1000;

DateFormat get cookieFormat => new DateFormat("EEE, dd MMM yyyy HH:mm:ss");

String toUTCString(int days) {
  if (days != 0) { 
    var date = new DateTime.now();
    date = new DateTime.fromMillisecondsSinceEpoch(
        date.millisecondsSinceEpoch + days*theDay, isUtc: true);
    return " expires=${cookieFormat.format(date)} GMT";
  } else {
    return " ";
  }
}

void setCookie(String name, String value, int days, 
          {String path:'/', String domain:null}) {
  StringBuffer sb = new StringBuffer(
      "${Uri.encodeQueryComponent(name)}=" +
      "${Uri.encodeQueryComponent(value)};");
  sb.write(toUTCString(days));
  sb.write("path=${Uri.encodeFull(path)}; ");
  if (domain != null) {
    sb.write("domain=${Uri.encodeFull(domain)}; ");
  }
  document.cookie = sb.toString();
}

String getCookie(String name) {
  var cName = name + "=";
  List<String> cookies = document.cookie.split("; ");
  for (String cookie in cookies) {
    if (cookie.startsWith(cName)) {
      return cookie.substring(cName.length);
    }
  }
  return null;
}

void removeCookie(String name) {
  setCookie(name, '', -1);
}