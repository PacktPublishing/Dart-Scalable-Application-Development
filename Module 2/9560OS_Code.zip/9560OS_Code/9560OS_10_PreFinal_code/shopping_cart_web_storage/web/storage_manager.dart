library storage_manager;

import 'dart:html';
import 'dart:async';

import 'cookie.dart';

abstract class StorageManager {
  factory StorageManager() {
    if (WebStorageManager.supported) {
      return new WebStorageManager();
    } else {
      return new CookieStorageManager();
    }
  }
  
  Future<String> getItem(key);
  Future setItem(key, value);
  Future removeItem(key);
}

class CookieStorageManager implements StorageManager {
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return getCookie(key);
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      setCookie(key, value, 365);
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      removeCookie(key);
    });
  }
}

class WebStorageManager implements StorageManager {
  
  static bool get supported {
    if (window.localStorage != null) {
      try{
        window.localStorage["__name__"] = "__test__";
        window.localStorage.remove("__name__");
        return true;
      } catch(e) {
        return false;
      }
    } else {
      return false;
    }
  }
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return window.localStorage[key];
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      window.localStorage[key] = value;
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      window.localStorage.remove(key);
    });
  }
}
