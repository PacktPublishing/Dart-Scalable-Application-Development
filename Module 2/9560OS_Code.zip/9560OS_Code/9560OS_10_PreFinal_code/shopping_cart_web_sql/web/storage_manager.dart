library storage_manager;

import 'dart:html';
import 'dart:async';
import 'dart:web_sql';

import 'cookie.dart';

abstract class StorageManager {
  factory StorageManager() {
    if (WebSQLStorageManager.supported) {
      return new WebSQLStorageManager();
    } else if (WebStorageManager.supported) {
      return new WebStorageManager();
    } else {
      return new CookieStorageManager();
    }
  }
  
  Future<String> getItem(key);
  Future setItem(key, value);
  Future removeItem(key);
}

class CookieStorageManager implements StorageManager {
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return getCookie(key);
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      setCookie(key, value, 365);
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      removeCookie(key);
    });
  }
}

class WebStorageManager implements StorageManager {
  
  static bool get supported {
    if (window.localStorage != null) {
      try{
        window.localStorage["__name__"] = "__test__";
        window.localStorage.remove("__name__");
        return true;
      } catch(e) {
        return false;
      }
    } else {
      return false;
    }
  }
  
  Future<String> getItem(key) {
    return new Future.sync(() {
      return window.localStorage[key];
    });
  }
  
  Future setItem(key, value) {
    return new Future.sync(() {
      window.localStorage[key] = value;
    });
  }
  
  Future removeItem(key) {
    return new Future.sync(() {
      window.localStorage.remove(key);
    });
  }
}

class WebSQLStorageManager implements StorageManager {
  
  static const SHOPPING = "SHOPPING";
  static const PRODUCT = "PRODUCT";
  static const TRANS_MODE = "readwrite";
  
  static final String VERSION = "1";
  static const int SIZE = 1048576;

  SqlDatabase _database;
  
  static bool get supported => SqlDatabase.supported;
  
  Future<SqlDatabase> _getDatabase(String dbName, String storeName) {
    if (_database == null) {
      _database = window.openDatabase(dbName, VERSION, dbName, SIZE);
      var sql = 'CREATE TABLE IF NOT EXISTS ' + 
          storeName + 
          ' (id NVARCHAR(32) UNIQUE PRIMARY KEY, value TEXT)';
      var completer = new Completer();
      _database.transaction((SqlTransaction tx) {
        tx.executeSql(sql, [], (SqlTransaction txn, SqlResultSet result) {
          completer.complete(_database);
        }, (SqlTransaction transaction, SqlError error) {
          completer.completeError(error);
        });
      }, (error) => completer.completeError(error));
      return completer.future;
    } else {
      return new Future.sync(() => _database);
    }
  }
  
  Future<String> getItem(key) {
    var sql = 'SELECT value FROM $PRODUCT WHERE id = ?';
    var completer = new Completer();
    _getDatabase(SHOPPING, PRODUCT).then((SqlDatabase database) {
      database.readTransaction((SqlTransaction tx) {
        tx.executeSql(sql, [key], (SqlTransaction txn, SqlResultSet result) {
          if (result.rows.isEmpty) {
            return completer.complete(null);
          } else {
            Map row = result.rows.first;
            return completer.complete(row['value']);
          }
        }, (SqlTransaction transaction, SqlError error) {
          completer.completeError(error);
        });
      });
    });
    return completer.future;
  }
  
  Future setItem(key, value) {
    var sql = 'INSERT OR REPLACE INTO $PRODUCT (id, value) VALUES (?, ?)';
    var completer = new Completer();
    _getDatabase(SHOPPING, PRODUCT).then((SqlDatabase database) {
      database.transaction((SqlTransaction tx) {
        tx.executeSql(sql, [key, value], (SqlTransaction txn, SqlResultSet result) {
          return completer.complete(value);
        }, (SqlTransaction transaction, SqlError error) {
          completer.completeError(error);
        });
      }, (error) => completer.completeError(error));
    });
    return completer.future;
  }
  
  Future removeItem(key) {
    var sql = 'DELETE FROM $PRODUCT WHERE id = ?';
    var completer = new Completer();
    _getDatabase(SHOPPING, PRODUCT).then((SqlDatabase database) {
      database.transaction((SqlTransaction tx) {
        tx.executeSql(sql, [key], (SqlTransaction txn, SqlResultSet result) {
          return completer.complete();
        }, (SqlTransaction transaction, SqlError error) {
          completer.completeError(error);
        });
      }, (error) => completer.completeError(error));
    });
    return completer.future;
  }
}