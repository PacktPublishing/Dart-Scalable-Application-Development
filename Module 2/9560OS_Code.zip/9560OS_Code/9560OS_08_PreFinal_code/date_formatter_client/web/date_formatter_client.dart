import 'package:intl/date_symbol_data_http_request.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as path;

void main() {
  String datesPath = path.join(path.current, 
        path.fromUri("packages/intl/src/data/dates/"));
  initializeDateFormatting("pt_BR", datesPath)
  .then((_) {
    Intl.defaultLocale = "pt_BR";
    DateFormat df = new DateFormat("EEE, MMM d, yyyy");
    print(df.format(new DateTime.now()));
   }).catchError((err) {
    print(err);
  });
}
