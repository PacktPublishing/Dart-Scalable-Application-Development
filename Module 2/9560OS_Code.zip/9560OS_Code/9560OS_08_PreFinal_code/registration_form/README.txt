Use follow line to extract all messages into ARB file
pub run intl:extract_to_arb --output-dir=web web/registration_form.dart

Call next line to generate Dart libraries contain translaton from ARB files
pub run intl:generate_from_arb --output-dir=web web/registration_form.dart web/translate_en.arb web/translate_de.arb