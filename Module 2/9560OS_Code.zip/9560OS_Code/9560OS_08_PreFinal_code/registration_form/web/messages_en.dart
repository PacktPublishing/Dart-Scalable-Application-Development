/**
 * DO NOT EDIT. This is code generated via pkg/intl/generate_localized.dart
 * This is a library that provides messages for a en locale. All the
 * messages from the main program should be duplicated here with the same
 * function name.
 */

library messages_en;
import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

class MessageLookup extends MessageLookupByLibrary {

  get localeName => 'en';
  static copyrightLbl() => "Copyright 2014 עתיד ושיתוף";

  static femaleLbl() => "Female";

  static firstNameLbl() => "First name:";

  static formHead() => "Registration Form";

  static genderLbl() => "Gender:";

  static lastNameLbl() => "Last name:";

  static maleLbl() => "Male";

  static registerBtn() => "Register";


  final messages = const {
    "copyrightLbl" : copyrightLbl,
    "femaleLbl" : femaleLbl,
    "firstNameLbl" : firstNameLbl,
    "formHead" : formHead,
    "genderLbl" : genderLbl,
    "lastNameLbl" : lastNameLbl,
    "maleLbl" : maleLbl,
    "registerBtn" : registerBtn
  };
}