import 'dart:html';
import 'package:intl/intl.dart';
import 'messages_all.dart';

formHead() => Intl.message("Registration Form", 
    name:"formHead",
    desc: "Registration Form title");
firstNameLbl() => Intl.message("First name:",
    name: "firstNameLbl",
    desc: "First Name label");
lastNameLbl() => Intl.message("Last name:", 
    name: "lastNameLbl", 
    desc: "Last Name label");
genderLbl() => Intl.message("Gender:",
    name: "genderLbl",
    desc: "Gender label");
maleLbl() => Intl.message("Male",
    name: "maleLbl",
    desc: "Male label");
femaleLbl() => Intl.message("Female",
    name: "femaleLbl",
    desc: "Female label");
registerBtn() => Intl.message("Register",
    name: "registerBtn",
    desc: "Registration Button name");
copyrightLbl() => Intl.message("Copyright 2014 עתיד ושיתוף",
    name: "copyrightLbl",
    desc: "Copyright label");

void main() {
  initializeMessages('de').then((_) {
    Intl.defaultLocale = 'de';
    querySelector("#formHead").text = formHead();
    querySelector("#firstNameLbl").text = firstNameLbl();
    querySelector("#lastNameLbl").text = lastNameLbl();
    querySelector("#genderLbl").text = genderLbl();
    querySelector("#maleLbl").text = maleLbl();
    querySelector("#femaleLbl").text = femaleLbl();
    (querySelector("#registerBtn") as InputElement)
      .value = registerBtn();
    BidiFormatter bidiFormatter = new BidiFormatter.UNKNOWN();
    querySelector("#copyrightLbl").text = 
      bidiFormatter.wrapWithUnicode(copyrightLbl());
  });
}
