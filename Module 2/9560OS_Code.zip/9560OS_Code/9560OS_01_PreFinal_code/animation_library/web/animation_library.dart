import 'animation_library_with_export.dart' as animation;

// Main entry into Dart Web application.
main() {
  // Animate
  new animation.Animation();
}