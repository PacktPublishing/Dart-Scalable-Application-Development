this.name = 'Unknown';

function sendMessage(message) {
  console.log('Send message: ' + this.name + ' ' + message);
}

function DieselEngine() {
  this.name = 'Diesel';
}

sendMessage('engine started');

var engine = new DieselEngine()

var dieselLog = sendMessage.bind(engine);
dieselLog('engine started');
