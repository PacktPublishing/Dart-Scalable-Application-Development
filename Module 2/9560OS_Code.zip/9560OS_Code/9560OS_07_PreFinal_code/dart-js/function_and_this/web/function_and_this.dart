import 'dart:js' as js;

void main() {
  var other = js.context['sendMessage'] = 
      new js.JsFunction.withThis(otherSendMessage);
  
  js.JsFunction DieselEngine = js.context['DieselEngine'];
  js.JsObject engine = new js.JsObject(DieselEngine);
  
  js.JsFunction sendMessage = js.context['sendMessage'];
  sendMessage.apply(['engine started'], thisArg: engine);
}

otherSendMessage(self, String message) {
  print('Message sent: ' + self['name'] + ' ' + message);
}
