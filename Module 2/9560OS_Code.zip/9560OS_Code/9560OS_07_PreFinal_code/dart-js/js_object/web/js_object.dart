import 'dart:js' as js;

void main() {
  js.JsObject console = js.context['console'];
  console.callMethod('log', ['Hello World!']);
}
