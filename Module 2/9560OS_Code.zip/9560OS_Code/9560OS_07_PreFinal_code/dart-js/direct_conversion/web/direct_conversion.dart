import 'dart:js' as js;
import 'dart:mirrors';

void main() {
  print(getFromJSContext('v_null'));
  print(getFromJSContext('v_bool'));
  print(getFromJSContext('v_num'));
  print(getFromJSContext('v_str'));
  print(getFromJSContext('v_date'));
  print(getFromJSContext('v_blob'));
  print(getFromJSContext('v_evt'));
  print(getFromJSContext('v_nodes'));
  print(getFromJSContext('v_img_data'));
  print(getFromJSContext('v_key_range'));
  print(getFromJSContext('v_node'));
  print(getFromJSContext('v_node_list'));
  print(getFromJSContext('v_typed'));
  print(getFromJSContext('v_byte_data'));
  print(getFromJSContext('v_global'));
}

getFromJSContext(name) {
  var obj = js.context[name];
  if (obj == null) {
    return name + ' = null';
  } else {
    return name + ' = ' + obj.toString() + ' is ' + getType(obj);
  }
}

getType(obj) {
  Symbol symbol = reflect(obj).type.qualifiedName;
  return MirrorSystem.getName(symbol); 
}
