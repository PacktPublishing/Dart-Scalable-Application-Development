var v_null = null;
var v_bool = true;
var v_num = 1.2;
var v_str = "Hello";
var v_date = new Date();
var v_blob = new Blob(
  ['<a id="a"><b id="b">hey!</b></a>'], 
  {type : 'text/html'});
var v_evt = new Event('click');
var v_nodes = document.createElement("form").children;
var v_img_data = document.createElement("canvas").
  getContext("2d").createImageData(10, 10);
var v_key_range = IDBKeyRange.only(100);
var v_node = document.createElement('div');
var v_node_list = document.createElement('div').childNodes;
var v_typed = new Int32Array(new ArrayBuffer(8));
var v_global = window;