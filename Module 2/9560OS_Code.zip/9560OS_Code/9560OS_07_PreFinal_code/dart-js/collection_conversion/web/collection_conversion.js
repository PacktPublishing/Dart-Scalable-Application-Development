function toType(obj) {
  return ({}).toString.call(obj).
    match(/\s([a-zA-Z]+)/)[1].toLowerCase()
};

var data;

function log() {
  console.log(toType(data));
  for (i in data) {
    console.log('- ' + i.toString() + ': ' + 
      data[i].toString() + ' (' + toType(data[i]) + ')');
  }
};