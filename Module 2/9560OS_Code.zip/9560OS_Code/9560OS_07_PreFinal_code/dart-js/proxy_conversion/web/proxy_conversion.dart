import 'dart:js' as js;
import 'dart:mirrors';

void main() {
  print(getFromJSContext('v_engine'));
}

getFromJSContext(name) {
  var obj = js.context[name];
  if (obj == null) {
    return name + ' = null';
  } else {
    return name + ' = ' + obj.toString() + ' is ' + getType(obj);
  }
}

getType(obj) {
  Symbol symbol = reflect(obj).type.qualifiedName;
  return MirrorSystem.getName(symbol); 
}