var Engine = function(type) {
  this.type = type;
  this.start = function() {
    alert('Started ' + type + ' engine');
  };
};

var v_engine = new Engine('test');