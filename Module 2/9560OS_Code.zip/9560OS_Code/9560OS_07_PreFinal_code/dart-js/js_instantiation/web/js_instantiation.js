function Engine(type) {
  this.type = type;
  this.start = function() {
    console.log('Started ' + type + ' engine');
  };
};
