import 'dart:js' as js;

void main() {
  js.JsFunction JsEngine = js.context['Engine'];
  js.JsObject engineObj = new js.JsObject(JsEngine, ['diesel']);
  assert(engineObj.instanceof(JsEngine));
  engineObj.callMethod('start');
}
