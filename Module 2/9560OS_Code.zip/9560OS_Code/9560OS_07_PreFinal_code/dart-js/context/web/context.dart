import 'dart:js' as js;

void main() {
  print('Context is ${js.context}');
}