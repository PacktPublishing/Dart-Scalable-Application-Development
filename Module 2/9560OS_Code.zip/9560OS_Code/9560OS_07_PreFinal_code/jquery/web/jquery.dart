import 'dart:html';
import 'package:js_proxy/js_proxy.dart';

/**
 * Shortcut for jQuery.
 */
var $ = new JProxy.fromContext('jQuery');

/**
 * Shortcut for browser console object.
 */
var console = window.console;

main() {
  printVersion();
  events();
  effects();
}

/**
 * jQuery code:
 * 
 *   var ver = $().jquery;
 *   console.log("jQuery version is " + ver);
 * 
 * JS_Proxy based analog:
 */
printVersion() {
  var ver = $().jquery;
  console.log("jQuery version is " + ver);
}

/**
 * jQuery code:
 * 
 *   $("button").click(function(){
 *     alert('You click on button');
 *   });
 * 
 * JS_Proxy based analog:
 */
events() {
  // We remove 'function' and add 'event' here
  $("button").click((event) {
    // Call method 'alert' of 'window'
    window.alert('You click on button');
  });
}

/**
 * jQuery code:
 * 
 *   $("p").click(function() {
 *     this.hide("slow",function(){
 *       alert("The paragraph is now hidden");
 *     });
 *   });
 *   $(".box").click(function(){
 *     var box = this;
 *     startAnimation();
 *     function startAnimation(){
 *       box.animate({height:300},"slow");
 *       box.animate({width:300},"slow");
 *       box.css("background-color","blue");  
 *       box.animate({height:100},"slow");
 *       box.animate({width:100},"slow",startAnimation);
 *     }
 *   }); 
 * 
 * JS_Proxy based analog:
 */
effects() {
  $("p").click((event) {
    $(event['target']).hide("slow",(){
      window.alert("The paragraph is now hidden");
    });
  });
  $(".box").click((event) {
    var box = $(event['target']); 
    startAnimation() {
      box.animate({'height':300},"slow");
      box.animate({'width':300},"slow");
      box.css("background-color","blue");  
      box.animate({'height':100},"slow");
      box.animate({'width':100},"slow",startAnimation);
    };
    startAnimation();
  });
}

