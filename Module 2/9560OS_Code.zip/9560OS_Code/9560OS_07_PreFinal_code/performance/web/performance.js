function run_js_test() {
  var startTime = new Date();
  //
  process_js();
  // 
  var diff = new Date(new Date().getTime() - startTime.getTime()).getTime();
  // 
  $('#result_js').text('jQuery tooks ' + diff + ' ms to process 10000 HTML elements.');
}

function process_js() {
  var container = $('#container');
  // Create 10000 DIV elements
  for (var i = 0; i < 10000; i++) {
    $('<div>Test</div>').appendTo(container);
  }
  // Find and update classes of all DIV elements
  $('#container > div').css("color","red");
  // Remove all DIV elements
  $('#container > div').remove();
}
      