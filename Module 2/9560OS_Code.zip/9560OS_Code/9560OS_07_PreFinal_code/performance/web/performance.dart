import 'dart:html';
import 'package:js_proxy/js_proxy.dart';

/**
 * Shortcut for jQuery.
 */
var $ = new JProxy.fromContext('jQuery');

/**
 * Shortcut for browser console object.
 */
var console = window.console;


void main() {
  querySelector('#run_jproxy').onClick.listen((event) {
    run_dart_js_test(process_jproxy, '#result_jproxy', 'JProxy');
  });
  querySelector('#run_dart').onClick.listen((event) {
    run_dart_js_test(process_dart, '#result_dart', 'Dart');
  });
}

run_dart_js_test(Function fun, String el, String title) {
  var startTime = new DateTime.now();
  //
  fun();
  // 
  //var diff = new DateTime.now(new DateTime.now().difference time() - startTime.getTime()).getTime();
  var  diff = new DateTime.now().difference(startTime);
  // 
  querySelector(el).text = '$title tooks ${diff.inMilliseconds} ms to process 10000 HTML elements.';
}

process_jproxy() {
  var container = $('#container');
  // Create 10000 DIV elements
  for (var i = 0; i < 10000; i++) {
    $('<div>Test</div>').appendTo(container.object);
  }
  // Find and update classes of all DIV elements
  $('#container > div').css("color","red");
  // Remove all DIV elements
  $('#container > div').remove();
}
 
process_dart() {
  // Create 10000 DIV elements
  var container = querySelector('#container');
  for (var i = 0; i < 10000; i++) {
    container.appendHtml('<div>Test</div>');
  }
  // Find and update classes of all DIV elements
  querySelectorAll('#container > div').forEach((Element el) {
    el.style.color = 'red';
  });
  // Remove all DIV elements
  querySelectorAll('#container > div').forEach((Element el) {
    el.remove();
  });
}