import 'dart:io';
import 'dart:async';
import 'package:route/server.dart';

import 'urls.dart' as urls;
import 'files.dart';

import 'dart:math';
Random dataGenerator = new Random(new DateTime.now().millisecondsSinceEpoch);

const EVENT_STREAM = "text/event-stream";

main() {
  final allUrls = new RegExp('/(.*)');

  HttpServer.bind(urls.serverAddress, urls.serverPort).then((server) {
    print("Server runs on ${server.address.host}:${server.port}");
    new Router(server)
        ..serve(urls.dataUrl, method: 'GET').listen(processSSE)
        ..serve(allUrls).listen(serveDirectory('', as: '/'))
        ..defaultStream.listen(send404);
  });
}

String fetchData() {
  return dataGenerator.nextInt(100).toString();
}

processSSE(HttpRequest request) {
  if (request.headers.value(HttpHeaders.ACCEPT) == EVENT_STREAM) {
    setHeaders(request.response);
    int num = 0;
    
    new Timer.periodic(new Duration(seconds:5), (Timer t) {
      sendMessageEvent(request.response, num++);
    });
    
    sendLogonEvent(request.response);
  }
}
  
setHeaders(HttpResponse response) {
  response.bufferOutput = false;
  response.headers.set(HttpHeaders.CONTENT_TYPE, EVENT_STREAM);
  response.headers.set(HttpHeaders.CACHE_CONTROL, 'no-cache');
  response.headers.set(HttpHeaders.CONNECTION, "keep-alive");
}

sendMessageEvent(HttpResponse response, int num) {
  print("Send Message event $num");
  response.writeln('id: 123');
  response.writeln('data: {"msg": "hello world", "num": $num, "value": ${fetchData()}}\n');
  response.flush();
}

sendLogonEvent(HttpResponse response) {
  print("Send Logon event");
  response.writeln('event: userlogon');
  response.writeln('id: 123');
  response.writeln('data: {"username": "John", "role": "admin"}\n');
  response.flush();
}