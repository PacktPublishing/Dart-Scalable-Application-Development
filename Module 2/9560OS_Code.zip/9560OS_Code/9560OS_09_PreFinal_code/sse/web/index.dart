import 'dart:html';
import 'urls.dart' as urls;

var url = "http://${urls.serverAddress}:${urls.serverPort}${urls.dataUrl}";

String get timeStamp {
  DateTime dt = new DateTime.now();
  return " (${dt.minute}:${dt.second})";
}

responseHandler(DivElement log, String data) {
  DivElement item = new DivElement();
  item.text = data + timeStamp;
  log.insertAdjacentElement('beforebegin', item);
}

main() {
  DivElement log = querySelector("#log");
  
  EventSource sse = new EventSource(url);
  
  sse.onOpen.listen((Event e) {
    responseHandler(log, "Connected to server: ${url}");
  });
  
  sse.onError.listen((Event e) {
    if (sse.readyState == EventSource.CLOSED) {
      responseHandler(log, "Connection closed");
    } else {
      responseHandler(log, "Error: ${e}");
    }
  });
  
  sse.onMessage.listen((MessageEvent e) {
    responseHandler(log, "Event ${e.lastEventId}: ${e.data}");
  });
  
  sse.addEventListener("userlogon", (Event e) {
    responseHandler(log, "User Logon: ${(e as MessageEvent).data}");
  }, false);
}