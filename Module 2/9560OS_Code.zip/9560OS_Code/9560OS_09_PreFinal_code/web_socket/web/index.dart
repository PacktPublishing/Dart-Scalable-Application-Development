import 'dart:html';
import 'dart:convert';
import 'dart:typed_data';
import 'urls.dart' as urls;

var url = "ws://${urls.serverAddress}:${urls.serverPort}${urls.dataUrl}";

String get timeStamp {
  DateTime dt = new DateTime.now();
  return " (${dt.minute}:${dt.second})";
}

responseHandler(DivElement log, String data) {
  DivElement item = new DivElement();
  item.text = data + timeStamp;
  log.insertAdjacentElement('beforebegin', item);
}

void main() {
  DivElement log = querySelector("#log");
  var webSocket = new WebSocket(url);
  if (webSocket != null) {
    webSocket.onOpen.listen((Event e) {
      responseHandler(log, "Connected to server: ${url}");
      sendData(webSocket);
    });
    webSocket.onError.listen((Event e) 
        => responseHandler(log, "Error: ${e}"));
    webSocket.onClose.listen((CloseEvent e) 
        => responseHandler(log, "Disconnected from server"));
    webSocket.onMessage.listen((MessageEvent e) 
        => responseHandler(log, "Event ${e.type}: ${e.data}"));
  }
}

sendData(WebSocket webSocket) {
  webSocket.send(JSON.encode({'name':'John', 'id':1234}));
  webSocket.sendString("Hello World");
  webSocket.sendTypedData(new Int16List.fromList([1, 2, 3]));
}