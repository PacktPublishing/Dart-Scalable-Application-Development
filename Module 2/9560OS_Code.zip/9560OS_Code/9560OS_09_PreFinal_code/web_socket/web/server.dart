import 'dart:io';
import 'package:route/server.dart';

import 'urls.dart' as urls;
import 'files.dart';

main() {
  final allUrls = new RegExp('/(.*)');

  HttpServer.bind(urls.serverAddress, urls.serverPort).then((server) {
    print("Server runs on ${server.address.host}:${server.port}");
    new Router(server)
        ..serve(urls.dataUrl).listen(processWS)
        ..serve(allUrls).listen(serveDirectory('', as: '/'))
        ..defaultStream.listen(send404);
  });
}

processWS(HttpRequest request) {
  WebSocketTransformer.upgrade(request).then((WebSocket webSocket) {
    webSocket.listen((data) {
      webSocket.add("Received $data");
    });
  });
}