import 'dart:io';
import 'dart:async';
import 'package:route/server.dart';

import 'urls.dart' as urls;
import 'files.dart';

import 'dart:math';
Random readyChecker = new Random(new DateTime.now().millisecondsSinceEpoch);
Random dataGenerator = new Random(new DateTime.now().millisecondsSinceEpoch);

main() {
  final allUrls = new RegExp('/(.*)');

  HttpServer.bind(urls.serverAddress, urls.serverPort).then((server) {
    print("Server runs on ${server.address.host}:${server.port}");
    new Router(server)
        ..serve(urls.dataUrl, method: 'GET').listen(longLasting)
        ..serve(allUrls).listen(serveDirectory('', as: '/'))
        ..defaultStream.listen(send404);
  });
}

setHeaders(HttpRequest request) {
  request.response.headers.contentType = 
    new ContentType("text", "plain", charset: "utf-8");
}

String fetchData() {
  return dataGenerator.nextInt(100).toString();
}

longLasting(HttpRequest request) {
  Timer reqTimer, dataReadyTimer;
  
  reqTimer = new Timer.periodic(new Duration(seconds:30), (Timer t){
    dataReadyTimer.cancel();
    processParams(request);
  });
  
  dataReadyTimer = new Timer.periodic(new Duration(seconds:1), (Timer t){
    if (readyChecker.nextBool()) {
      reqTimer.cancel();
      processParams(request, ready:true);
    }
  });
}

processParams(HttpRequest request, {bool ready:false}) {
  request.response.write(
      "${request.method}: ${request.uri.path}");
  if (ready) {
    request.response.write(", Data:" + fetchData());
  } else {
    request.response.write(", Data:");
  }
  if (request.uri.queryParameters.length > 0) {
    request.response.write(", Params:" + 
        request.uri.queryParameters.toString());
  }
  request.response.close();
}