library server.urls;

import 'package:route/url_pattern.dart';

final serverAddress = '127.0.0.1';
final serverPort = 8080;

final dataUrl = new UrlPattern('/data');
