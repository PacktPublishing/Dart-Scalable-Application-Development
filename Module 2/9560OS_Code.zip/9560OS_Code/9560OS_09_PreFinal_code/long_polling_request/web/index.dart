import 'dart:html';
import 'urls.dart' as urls;

var url = "http://${urls.serverAddress}:${urls.serverPort}${urls.dataUrl}";

String get timeStamp {
  DateTime dt = new DateTime.now();
  return " (${dt.minute}:${dt.second})";
}

responseHandler(DivElement log, responseText) {
  DivElement item = new DivElement()
  ..text = responseText.toString() + timeStamp;
  log.insertAdjacentElement('beforebegin', item);
}

void main() {
  DivElement log = querySelector("#log");
  int num = 0;
  longPolling(log, num);
}

longPolling(DivElement log, int num) {
  String query = "number=${num++}";
  HttpRequest.getString("$url?$query")
    .then((response) {
    responseHandler(log, response);
    longPolling(log, num);
  });
}