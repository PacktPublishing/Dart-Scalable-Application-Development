import 'dart:io';
import 'package:route/server.dart';

import 'urls.dart' as urls;
import 'files.dart';

import 'dart:math';
Random readyChecker = new Random(new DateTime.now().millisecondsSinceEpoch);
Random dataGenerator = new Random(new DateTime.now().millisecondsSinceEpoch);

main() {
  final allUrls = new RegExp('/(.*)');

  HttpServer.bind(urls.serverAddress, urls.serverPort).then((server) {
    print("Server runs on ${server.address.host}:${server.port}");
    new Router(server)
        ..serve(urls.dataUrl, method: 'GET').listen(processParams)
        ..serve(allUrls).listen(serveDirectory('', as: '/'))
        ..defaultStream.listen(send404);
  });
}

setHeaders(HttpRequest request) {
  request.response.headers.contentType = 
    new ContentType("text", "plain", charset: "utf-8");
}

String fetchData() {
  if (readyChecker.nextBool()) {
    return dataGenerator.nextInt(100).toString();
  } else {
    return " ";
  }
}

processParams(HttpRequest request) {
  setHeaders(request);
  request.response.write(
      "${request.method}: ${request.uri.path}");
  request.response.write(", Data:" + fetchData());
  if (request.uri.queryParameters.length > 0) {
    request.response.write(", Params:" + 
        request.uri.queryParameters.toString());
  }
  request.response.close();
}