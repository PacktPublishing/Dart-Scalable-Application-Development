import 'dart:io';
import 'package:route/server.dart';

import 'urls.dart' as urls;
import 'files.dart';

main() {
  final allUrls = new RegExp('/(.*)');

  HttpServer.bind(urls.serverAddress, urls.serverPort).then((server) {
    print("Server runs on ${server.address.host}:${server.port}");
    new Router(server)
        ..serve(urls.dataUrl, method: 'GET').listen(processParams)
        ..serve(urls.dataUrl, method: 'DELETE').listen(processParams)
        ..serve(urls.dataUrl, method: 'POST').listen(processBody)
        ..serve(urls.dataUrl, method: 'PUT').listen(processBody)
        ..serve(allUrls).listen(serveDirectory('', as: '/'))
        ..defaultStream.listen(send404);
  });
}

setHeaders(HttpRequest request) {
  request.response.headers.contentType = 
    new ContentType("text", "plain", charset: "utf-8");
}

processParams(HttpRequest request) {
  setHeaders(request);
  request.response.write(
      "${request.method}: ${request.uri.path}");
  if (request.uri.queryParameters.length > 0) {
    request.response.write(", Params:" + 
        request.uri.queryParameters.toString());
  }
  request.response.close();
}

processBody(HttpRequest request) {
  setHeaders(request);
  if (request.contentLength > 0) {
    request.listen((List<int> buffer) {
      request.response.write(
          "${request.method}: ${request.uri.path}");
      request.response.write(", Data:" + 
          new String.fromCharCodes(buffer));
      request.response.close();
    });
  } else {
    request.response.write(
        "${request.method}: ${request.uri.path}");
    request.response.close();
  }
}