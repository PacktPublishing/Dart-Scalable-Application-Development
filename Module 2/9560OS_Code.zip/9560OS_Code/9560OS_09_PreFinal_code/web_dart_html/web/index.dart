import 'dart:html';
import 'dart:convert';
import 'urls.dart' as urls;

var url = "http://${urls.serverAddress}:${urls.serverPort}${urls.dataUrl}";
var name = "HttpClient Browser";
// We save the response text in a DIV element and append it to the
// DIV container:
responseHandler(DivElement log, responseText) {
  DivElement item = new DivElement()
  ..text = responseText.toString();
  log.append(item);
}


void main() {
  DivElement log = querySelector("#log");
  // Here we prepare query to send:
  String query = "name=" + Uri.encodeQueryComponent(name);
  String data = JSON.encode({"name": name});
  
  HttpRequest request = new HttpRequest();
  // We open a connection to the server via HttpRequest:
  request.open("GET", "$url?$query");
  request.onLoad.listen((ProgressEvent event) {
    responseHandler(log, request.response);
  });
  // Now send data via call the send method:
  request.send();
  
  request.open("POST", "$url?$query");
  request.onLoad.listen((ProgressEvent event) {
    responseHandler(log, request.response);
  });
  request.send(data);
  
  request.open("PUT", "$url?$query");
  request.onLoad.listen((ProgressEvent event) {
    responseHandler(log, request.response);
  });
  request.send(data);
  
  request.open("DELETE", "$url?$query");
  request.onLoad.listen((ProgressEvent event) {
    responseHandler(log, request.response);
  });
  request.send();
  
  // HttpRequest supports less verbose code:  
  HttpRequest.request("$url?$query")
  .then((HttpRequest request) => responseHandler(log, request.response));
  
  HttpRequest.request(url, method: "POST", sendData: data)
  .then((HttpRequest request) => responseHandler(log, request.response));
  
  HttpRequest.request(url, method: "PUT", sendData: data)
  .then((HttpRequest request) => responseHandler(log, request.response));
  
  HttpRequest.request("$url?$query", method: "DELETE")
  .then((HttpRequest request) => responseHandler(log, request.response));
  
  // The getString method is the absolute champion of size
  // if you need a simple GET request:
  HttpRequest.getString("$url?$query")
  .then((response) => responseHandler(log, response));  
}