import 'dart:html' as dom;
import 'package:http/browser_client.dart';
import 'package:http/src/request.dart';
import 'package:http/src/streamed_response.dart';
import 'dart:convert';
import 'urls.dart' as urls;

var url = "http://${urls.serverAddress}:${urls.serverPort}${urls.dataUrl}";
var name = "HttpClient Browser";
// The response handler is as follows:
responseHandler(dom.DivElement log, StreamedResponse response) {
  dom.DivElement item = new dom.DivElement();
  response.stream.transform(UTF8.decoder).listen((contents) {
    item.text = contents;
  });
  log.append(item);
}

void main() {
  dom.DivElement log = dom.querySelector("#log");
  String query = "name=" + Uri.encodeQueryComponent(name);
  String data = JSON.encode({"name": name});
  
  BrowserClient client = new BrowserClient();
  Request request = new Request("GET", Uri.parse("$url?$query"));
  // We organize request via call the send method of BrowserClient
  // class:
  client.send(request).then((StreamedResponse response) 
      => responseHandler(log, response));
  
  request = new Request("POST", Uri.parse(url));
  request.body = data;
  client.send(request).then((StreamedResponse response) 
      => responseHandler(log, response));
  
  request = new Request("PUT", Uri.parse(url));
  request.body = data;
  client.send(request).then((StreamedResponse response) 
      => responseHandler(log, response));
  
  request = new Request("DELETE", Uri.parse("$url?$query"));
  client.send(request).then((StreamedResponse response) 
      => responseHandler(log, response));
}