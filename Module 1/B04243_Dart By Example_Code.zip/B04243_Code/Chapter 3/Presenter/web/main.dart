import "lib/slideshowapp.dart";

void main() {
  new SlideShowApp();
}

