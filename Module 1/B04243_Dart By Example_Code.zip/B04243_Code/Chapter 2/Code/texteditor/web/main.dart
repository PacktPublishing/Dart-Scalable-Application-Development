import 'dart:html';
import 'dart:async';
import 'editor.dart';
import 'package:intl/intl.dart';

TextEditor theEditor;

void main() {

  //Set up the Editor.
  theEditor = new TextEditor(querySelector("#editor"));

  //Connect Toolbar items to the Editor methods.
  var btnClear = querySelector("#btnClearText");
  var btnDownload = querySelector("#btnDownload");
  var btnAbout = querySelector("#btnAbout");
  var btnClassGen = querySelector("#btnClassGen");
  var btnWordCount = querySelector("#btnWordCount");
  var btnFreq = querySelector("#btnFreq");
  var btnStat = querySelector("#btnCodeStats");

  btnClear.onClick.listen(theEditor.clearEditor);
  btnDownload.onClick.listen(theEditor.downloadFile);
  btnWordCount.onClick.listen(theEditor.showWordCount);
  btnFreq.onClick.listen(theEditor.showFreqCount);
  btnClassGen.onClick.listen(theEditor.showClassGen);
  btnStat.onClick.listen(theEditor.showStats);
  btnAbout.onClick.listen(theEditor.showAbout);

  //Clock
  new Timer.periodic(new Duration(seconds: 1),
      (timer) => querySelector("#clock").text =
          (new DateFormat('HH:mm')).format(new DateTime.now()));
}
