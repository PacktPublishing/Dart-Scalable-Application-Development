/// Class generator.
import 'dart:html';
import 'dart:math';
import 'package:simple_dialog/simple_dialog.dart';
import 'source_scan.dart';

const String punctuation = ",.-!\"";

///Word Frequency Dialog
class WordFreqDialog extends Dialog {
  WordFreqDialog(String titleText, String txt)
      : super("Word Frequency", "", 400, 390, true, false) {
    contentDiv..style.textAlign = "center";

    countFrequency(txt);
  }

  /// Count the occurrences of each word.
  void countFrequency(String text) {
    Map<String, int> wordFreqCounts = {};
    String out = "";

    for (var character
        in punctuation.split('')) text = text.replaceAll(character, " ");
    text = text.toLowerCase();

    List<String> words = text.split(" ");
    words
      ..removeWhere((word) => word == " ")
      ..removeWhere((word) => word.length == 0)
      ..forEach((word) {
        if (wordFreqCounts.containsKey(word)) wordFreqCounts[word] =
            wordFreqCounts[word] + 1;
        else wordFreqCounts[word] = 1;
      });

    wordFreqCounts
        .forEach((k, v) => out += ("<tr><td>$k</td><td>$v</td></tr>"));
    contentDiv
      ..appendHtml("<table align=\"center\">$out</table>")
      ..style.height = "290px"
      ..style.width = "380px"
      ..style.overflowY = "scroll";
  }
}

///Class Generator Dialog
class GenClassDialog extends Dialog {
  TextInputElement name;
  TextAreaElement fields;
  TextAreaElement methods;

  GenClassDialog() : super("Dart Class Generator", "", 400, 375) {
    name = new TextInputElement();
    name
      ..placeholder = "Name"
      ..style.width = "90%";

    fields = new TextAreaElement();
    fields
      ..rows = 6
      ..placeholder = "Fields  (new line after each)"
      ..style.resize = "none"
      ..style.width = "90%";

    methods = new TextAreaElement();
    methods
      ..rows = 6
      ..placeholder = "Methods (new line after each)"
      ..style.resize = "none"
      ..style.width = "90%";

    contentDiv
      ..append(name)
      ..append(new BRElement())
      ..append(new BRElement())
      ..append(fields)
      ..append(new BRElement())
      ..append(new BRElement())
      ..append(methods);
  }

  // Set OK status and call result handler if set.
  void setOKStatus(MouseEvent me) {
    hide(null);
    makeClass();
    resultHandler("ok");
  }

  // Create the actual source code from the Use input.
  void makeClass() {
    String className = name.value;
    String fieldsSrc = "";
    String methodsSrc = "";

    List<String> classFields = fields.value.split("\n");
    List<String> classMethods = methods.value.split("\n");

    classFields.forEach((field) => fieldsSrc += "    var $field;\n");
    classMethods.forEach((method) => methodsSrc += "    $method(){};\n");

    result = """   /// The $className Class.
   class $className {

$fieldsSrc

    $className(){}

$methodsSrc

   }
    """;
  }
}

///Source Code Stats Dialog
class CodeStatsDialog extends Dialog {
  CanvasRenderingContext2D c2d;

  /// Constructor.
  CodeStatsDialog() : super("Source Code Stats", "", 510, 400, true, false) {
    var name = new TextInputElement();
    name.placeholder = "Name";

    var fields = new TextAreaElement();
    fields.placeholder = "Fields";

    var methods = new TextAreaElement();
    methods.placeholder = "Methods";

    CanvasElement graphs = new CanvasElement();
    graphs.width = 500;
    graphs.height = 270;
    c2d = graphs.getContext("2d");

    contentDiv..append(new BRElement())..append(graphs);
  }

  /// Process the code and build the pie chart.
  void scanCode(String srcCode) {

    // Get the stats.
    List<double> data = [0.0, 0.0, 0.0, 0.0];
    double totalLines = 0.0;
    SourceCodeScanner scScanner = new SourceCodeScanner();

    scScanner.scan(srcCode.split('\n'));
    data[0] = (scScanner.totalLines -
            (scScanner.comments + scScanner.whitespace + scScanner.imports))
        .roundToDouble();
    data[1] = scScanner.comments.roundToDouble();
    data[2] = scScanner.imports.roundToDouble();
    data[3] = scScanner.whitespace.roundToDouble();
    totalLines = scScanner.totalLines.roundToDouble();

    // Display Pie chart.
    double lastpos = 0.0;
    var labels = ['Code', 'Comments', 'Imports', 'Whitespace'];
    var colors = ['red', 'green', 'blue', 'yellow'];
    int radius = 130;

    for (int i = 0; i < 4; i++) {
      c2d
        ..fillStyle = colors[i]
        ..strokeStyle = "black"
        ..beginPath()
        ..moveTo(radius, radius)
        ..arc(radius, radius, radius, lastpos,
            (lastpos + (PI * 2.0 * (data[i] / totalLines))), false)
        ..lineTo(radius, radius)
        ..fill()
        ..stroke()
        ..closePath();
      lastpos += PI * 2.0 * (data[i] / totalLines);
      print(lastpos);

      c2d
        ..beginPath()
        ..strokeStyle = "black"
        ..fillStyle = colors[i]
        ..fillRect(380, 90 + 20 * i, 8, 8)
        ..strokeRect(380, 90 + 20 * i, 8, 8)
        ..strokeText(labels[i], 400, 100 + 20 * i)
        ..stroke()
        ..closePath();
    }
  }
}
