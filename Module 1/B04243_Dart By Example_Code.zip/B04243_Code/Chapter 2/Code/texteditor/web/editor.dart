import 'dart:convert';
import 'dart:html';
import 'package:simple_dialog/simple_dialog.dart';
import 'custom_dialogs.dart';

/// The TextEditor class - handling load/save and utilities.
class TextEditor {
  final String appTitle = "TextEditor";
  final TextAreaElement theEditor;

  GenClassDialog gcd;

  TextEditor(this.theEditor) {
    theEditor
      ..onKeyUp.listen(handleKeyPress)
      ..value = loadDocument();
  }

  // Event Handlers. -------------
  void handleKeyPress(KeyboardEvent event) {
    saveDocument();
  }

  void clearEditor(MouseEvent event) {
    confirm(appTitle, "Are you sure you want to clear the text?", 400, 120,
        performClear);
  }

  void showAbout(MouseEvent event) {
    AboutDialog textEditorAbout = new AboutDialog(appTitle,
        "TextEditor for the Web", "http://www.packtpub.com", "Homepage", 300,
        200);
    textEditorAbout.show();
  }

  void showWordCount(MouseEvent event) {
    String txt = theEditor.value;
    for (var c in punctuation.split('')) txt = txt.replaceAll(c, " ");

    List<String> words = txt.split(" ");
    words..removeWhere((s) => s == " ")..removeWhere((s) => s.length == 0);

    alert(appTitle, "Word Count ${words.length}", 200, 120);
  }

  void showFreqCount(MouseEvent event) {
    WordFreqDialog wfd = new WordFreqDialog(appTitle, theEditor.value);
    wfd.show();
  }

  void showClassGen(MouseEvent event) {
    gcd = new GenClassDialog();
    gcd.show(createClassCode);
  }

  void showStats(MouseEvent event) {
    CodeStatsDialog csd = new CodeStatsDialog();
    csd.scanCode(theEditor.value);
    csd.show();
  }

  void downloadFile(MouseEvent event) {
    downloadFileToClient("TextEditor.txt", theEditor.value);
  }

  // Actions. -------------
  void performClear(String result) {
    if (result == "ok") {
      theEditor.value = "";
      window.localStorage["MyTextEditor"] = "";
    }
  }

  String loadDocument() {
    String readings = "";
    String jsonString = window.localStorage["MyTextEditor"];
    if (jsonString != null && jsonString.length > 0) readings =
        JSON.decode(jsonString);

    return readings;
  }

  void saveDocument() {
    window.localStorage["MyTextEditor"] = JSON.encode(theEditor.value);
  }

  void downloadFileToClient(String filename, String text) {
    AnchorElement tempLink = document.createElement('a');
    tempLink
      ..attributes['href'] =
      'data:text/plain;charset=utf-8,' + Uri.encodeComponent(text)
      ..attributes['download'] = filename
      ..click();
  }

  void createClassCode(String result) {
    theEditor.value = gcd.result;
  }
}
