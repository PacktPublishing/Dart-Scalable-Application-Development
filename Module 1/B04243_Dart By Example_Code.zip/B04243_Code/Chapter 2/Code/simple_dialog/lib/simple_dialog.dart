library simple_dialog;

import 'dart:html';

part 'src/dialog_base.dart';
part 'src/prefabs.dart';