library geoapi;

import 'package:rpc/rpc.dart';
import 'dart:async';
import 'daoapi.dart';

@ApiClass(
    name: 'quake',
    version: 'v1',
    description: 'Rest API for Earthquake feature data.')
class Quake {
  @ApiMethod(path: 'hello')
  QuakeResponse hello() {
    return new QuakeResponse()..result = 'Hello world.';
  }

  @ApiMethod(path: 'implementationerror')
  QuakeResponse implementationError() {
    throw new Exception();
  }

  @ApiMethod(path: 'latest')
  Future<List<String>> latest() async {
    DaoQuakeAPI quakeAPI = new DaoQuakeAPI();
    return await quakeAPI.fetchTopTenLatest();
  }
}

///Helper response class.
class QuakeResponse {
  String result;
  QuakeResponse();
}
