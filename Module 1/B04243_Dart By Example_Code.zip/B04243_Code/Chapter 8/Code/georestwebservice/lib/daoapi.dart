import 'package:postgresql/postgresql.dart';
import 'dart:async';

var uri = 'postgres://webquakeuser:Coco99nut@localhost:5432/quakedata';

class DaoQuakeAPI {
  DaoQuake() {}

  Future<List<String>> fetchTopTenLatest() async {
    var dbConn;
    try {
      dbConn = await connect(uri);

      var query = """
      select geojson from dm_quakefeatures order by modified_date desc limit 10
      """;

      List<Row> dbResults = await dbConn.query(query).toList();
      List<String> results = new List<String>();

      dbResults.forEach((record) {
        results.add(record[0]);
      });

      return results;
    } catch (exception, stackTrace) {
      print(exception);
      print(stackTrace);
    } finally {
      dbConn.close();
    }
  }
}
