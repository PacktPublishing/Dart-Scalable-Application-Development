import 'dart:html';
import 'dart:core';
import 'dart:convert';
import 'dart:async';

import 'package:intl/intl.dart';
import 'package:webgridview/webgridview.dart';

const String jsonSrc = "http://127.0.0.1:8080/api/quake/v1/latest";
Timer updater = null;
int secondsToUpdate = 60;

// Main entry point.
void main() {
  performUpdate(null);
  updater = new Timer.periodic(new Duration(seconds: 10), performUpdate);
}

// Update handler for page.
void performUpdate(Timer triggerTimer) {
  DivElement outputDiv = querySelector('#timestatus');

  DateTime currentDateTime = new DateTime.now();
  DateFormat timeStamp = new DateFormat("hh:mm a");

  if (triggerTimer != null) {
    secondsToUpdate -= 10;
  } else updateDataView();

  if (secondsToUpdate == 0) {
    updateDataView();
    secondsToUpdate = 60;
  }

  outputDiv.text =
      "${timeStamp.format(currentDateTime)} - $secondsToUpdate seconds until refresh.";
}

// Update for the grid view of the data.
void updateDataView() {
  DivElement outputDiv = querySelector('#output');

  HttpRequest.getString(jsonSrc).then((String data) {
    outputDiv.children.clear();

    List items;
    try {
      items = JSON.decode(data);
    } catch (exception, stackTrace) {
      print(exception);
      print(stackTrace);
    }

    if (items != null) {
      List allQuakeData = [];
      allQuakeData.add(
          ['Time', 'Magnitude', 'Type', 'Tsunami', 'Place', 'Sig', 'Link']);

      items.forEach((String post) {
        Map decodedData = JSON.decode(post);

        List quakeData = [];
        quakeData.add(convertTime(decodedData['properties']['time']));
        quakeData.add(decodedData['properties']['mag']);
        quakeData.add(decodedData['properties']['type']);
        quakeData.add(decodedData['properties']['tsunami']);
        quakeData.add(decodedData['properties']['place']);
        quakeData.add(decodedData['properties']['sig']);
        quakeData.add(decodedData['properties']['url']);

        allQuakeData.add(quakeData);
      });

      outputDiv.append(Gridview.getTable(allQuakeData));
    }
  });
}

// Convert time to something for humans.
String convertTime(int time) {
  DateTime datetime = new DateTime.fromMillisecondsSinceEpoch(time);
  DateFormat timeStamp = new DateFormat("hh:mm:ss a");
  return timeStamp.format(datetime);
}
