library webgridview.base;

import 'dart:html';

class Gridview {

  ///Create a grid with a custom element.
  static TableElement getTable(List rows) {
    TableElement te = new TableElement();
    rows.forEach((row) => addRow(te, row));
    return te;
  }

  static addRow(TableElement table, List cols) {
    TableRowElement tableRow = table.addRow();

    cols.forEach((column) {
      TableCellElement tableCell = tableRow.addCell();
      String content = column.toString();
      if (content.startsWith('http')) {
        content = "<a href=\"$content\">Link</a>";
        tableCell.appendHtml(content);
      } else tableCell.text = content;
    });
  }
}
