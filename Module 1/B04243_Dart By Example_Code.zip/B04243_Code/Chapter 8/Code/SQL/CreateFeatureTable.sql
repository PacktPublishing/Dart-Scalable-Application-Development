CREATE TABLE dm_quakefeatures
(
  qufeat_id text NOT NULL,
  geojson text NOT NULL,
  modified_date timestamp without time zone DEFAULT now(),
  CONSTRAINT dm_qufeat_pkey PRIMARY KEY (qufeat_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE dm_quakefeatures
  OWNER TO webquakeuser;
