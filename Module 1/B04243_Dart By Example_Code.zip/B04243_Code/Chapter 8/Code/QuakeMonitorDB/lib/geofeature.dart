library GeoFeature;

import 'dart:convert' show JSON;

/// GeoFeature object.
class GeoFeature {
  String id;

  Map properties;
  Map geometry;

  String type;
  String title;
  String mag;
  String place;
  String time;

  String url;
  String detail;

  GeoFeature(Map newProperties) {
    properties = newProperties["properties"];
    geometry = newProperties["geometry"];
    id = newProperties["id"];
    time = properties["time"].toString();
    title = properties["title"].toString();
    type = properties["type"].toString();
    mag = properties["mag"].toString();
    place = properties["place"].toString();

    url = properties["url"].toString();
    detail = properties["detail"].toString();
  }

  String toString() {
    return "$id $title $type  $mag $place $time ";
  }

  String toJson() {
    Map out = {};
    out["properties"] = properties;
    out["geometry"] = geometry;
    return JSON.encode(out);
  }
}
