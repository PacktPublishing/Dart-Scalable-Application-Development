library GeoUpdate;

import 'dart:convert' show JSON;
import 'geofeature.dart';

/// GeoUpdate class.
class GeoUpdate {
  String src;
  List features;

  GeoUpdate(String json) {
    src = json;
    features = [];

    if (src.length > 0) {
      try {
        Map rawJsonObj = JSON.decode(src);

        if (rawJsonObj["features"] != null) {
          var items = rawJsonObj["features"];

          items.forEach((Map i) {
            features.add(new GeoFeature(i));
          });
        }
      } catch (exception) {
        print("Error decoding JSON.");
        print("$src");
        print(exception);
      }
    }
  }
}
