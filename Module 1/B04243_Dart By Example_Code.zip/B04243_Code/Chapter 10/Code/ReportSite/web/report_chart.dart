library report.chart;

import 'dart:convert';
import 'dart:html';
import 'package:modern_charts/modern_charts.dart';

const String jsonSrc = "http://127.0.0.1:8080/api/quake/v1/recent/20";

performChart(MouseEvent event) async {
  String json = await HttpRequest.getString(jsonSrc);
  List<String> items = JSON.decode(json);
  List dataset = [['Place', 'Magnitude']];

  items.forEach((String featureJSON) {
    Map feature = JSON.decode(featureJSON);
    String place = feature['properties']['place'];
    place = place.substring(place.lastIndexOf(",") + 1);

    if (place.length > 5) place = place.substring(0, 5) + ".";
    var mag = feature['properties']['mag'];
    dataset.add([place, mag]);
  });

  DataTable table = new DataTable(dataset);

  Map options = {
    'colors': ['#3333cb'],
    'series': {'labels': {'enabled': true}}
  };

  DivElement container = new DivElement();
  container
    ..id = "chartContainer"
    ..style.width = "90%"
    ..style.height = "90%";

  var Title = new HeadingElement.h1();
  Title.text = "Quake Chart";
  document.body.nodes
    ..clear()
    ..add(Title)
    ..add(container);

  LineChart chart = new LineChart(container);
  chart.draw(table, options);
}
