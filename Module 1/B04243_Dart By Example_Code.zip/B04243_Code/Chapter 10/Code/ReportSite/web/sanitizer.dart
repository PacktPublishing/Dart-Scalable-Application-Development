import 'dart:html';

class ReportSanitizer implements NodeTreeSanitizer {
  void sanitizeTree(Node node) {}
}
