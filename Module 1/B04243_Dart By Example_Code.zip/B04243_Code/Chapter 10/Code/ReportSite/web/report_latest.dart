library report.latest;

import 'dart:html';
import 'dart:convert';
import 'package:reports/reports.dart';
import 'sanitizer.dart';

const String jsonSrc = "http://127.0.0.1:8080/api/quake/v1/recent/100";

String buildFeatureTable(List<String> items) {
  String table =
      "<tr><th>Type</th><th>Time</th><th>Place</th><th>Magnitiude</th></tr>";

  items.forEach((String featureJSON) {
    Map feature = JSON.decode(featureJSON);
    String type = feature['properties']['type'];
    String place = feature['properties']['place'];
    var mag = feature['properties']['mag'];
    var time =
        new DateTime.fromMillisecondsSinceEpoch(feature['properties']['time']);
    String row =
        "<tr><td>$type</td><td>$time</td><td>$place</td><td>$mag</td>\n";
    table += row;
  });
  return table;
}

performLatest(MouseEvent event) async {
  String json = await HttpRequest.getString(jsonSrc);
  List<String> items = JSON.decode(json);
  DateTime datetime = new DateTime.now();

  Report report = new Report('Latest');
  report
    ..addSection(new Title("Latest Quake Data Report"))
    ..addSection(new Paragraph(
        '<div style="align:center"><img src="img/logo.png"/></div>'))
    ..addSection(new Paragraph("Report Generated At : ${datetime}"))
    ..addSection(new Pagebreak());

  var table = buildFeatureTable(items);

  report
    ..addSection(new Paragraph('<table id="reporttable">' + table + '</table>'))
    ..addSection(new Pagebreak())
    ..addSection(new Notes("Looks like a busy day!"))
    ..generate();

  querySelector('body').setInnerHtml(report.output.toString(),
      treeSanitizer: new ReportSanitizer());
}
