library report.export;

import 'dart:html';
import 'dart:convert';

import 'sanitizer.dart';

const String jsonSrc = "http://127.0.0.1:8080/api/quake/v1/recent/50";

performExport(MouseEvent event) async {
  String json = await HttpRequest.getString(jsonSrc);
  List<String> items = JSON.decode(json);
  String csvexport = "Type, Time, Place, Magnitude\r\n";

  items.forEach((String featureJSON) {
    Map feature = JSON.decode(featureJSON);
    String type = feature['properties']['type'];
    String place = feature['properties']['place'];
    var mag = feature['properties']['mag'];
    var time =
        new DateTime.fromMillisecondsSinceEpoch(feature['properties']['time']);
    String row = "$type, $time, ${place.replaceAll(",","")}, $mag\r\n";
    csvexport += row;
  });

  querySelector('body').setInnerHtml('<pre>$csvexport</pre>',
      treeSanitizer: new ReportSanitizer());
}
