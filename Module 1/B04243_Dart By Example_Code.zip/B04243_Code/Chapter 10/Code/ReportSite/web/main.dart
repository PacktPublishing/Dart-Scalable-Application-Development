import 'dart:html';
import 'report_latest.dart';
import 'report_csv.dart';
import 'report_chart.dart';

void main() {
  DateTime datetime = new DateTime.now();
  querySelector('#output').text = datetime.toString();
  querySelector('#LatestButton').onClick.listen(performLatest);
  querySelector('#ChartButton').onClick.listen(performChart);
  querySelector('#ExportButton').onClick.listen(performExport);
}

