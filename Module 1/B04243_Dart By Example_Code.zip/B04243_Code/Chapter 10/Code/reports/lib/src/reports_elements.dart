library reports.elements;

abstract class Element {
  void setContent(var content);
  String toHtml();
}

class Title implements Element {
  String content;

  Title(this.content) {}

  @override
  void setContent(var content) {
    String input = content.toString();
    content = input;
  }

  @override
  String toHtml() {
    return "<h1>$content</h1>";
  }
}

class Paragraph implements Element {
  String content;

  Paragraph(this.content) {}

  @override
  void setContent(var content) {
    String input = content.toString();
    content = input;
  }

  @override
  String toHtml() {
    return "<p>$content</p>";
  }
}

class Pagebreak implements Element {
  String content;

  Pagebreak() {}

  @override
  void setContent(var content) {}

  @override
  String toHtml() {
    return '<div style="page-break-after:always">&nbsp;</div>';
  }
}

class Notes implements Element {
  String content;

  Notes(this.content) {}

  @override
  void setContent(var content) {
    String input = content.toString();
    content = input;
  }

  @override
  String toHtml() {
    return "<h2>Notes</h2><p>$content</p>";
  }
}

class Table implements Element {
  String content;

  Table(this.content) {}

  @override
  void setContent(var content) {
    String input = content.toString();
    content = input;
  }

  @override
  String toHtml() {
    return "<p>$content</p>";
  }
}
