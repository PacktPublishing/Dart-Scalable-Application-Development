library reports.base;

import 'reports_elements.dart';

/// Report Object
class Report {
  String title;
  StringBuffer output;
  DateTime generatedTimestamp;
  List<Element> allContent;

  Report(this.title) {
    allContent = new List<Element>();
  }

  void addSection(Element section) {
    allContent.add(section);
  }

  void addPageBreak() {
    allContent.add(new Pagebreak());
  }

  void addNotes() {
    allContent.add(new Notes("Test note."));
  }

  bool generate() {
    output = new StringBuffer();
    allContent.forEach((content) {
      output.write(content.toHtml());
    });
    generatedTimestamp = new DateTime.now();
    return true;
  }
}
