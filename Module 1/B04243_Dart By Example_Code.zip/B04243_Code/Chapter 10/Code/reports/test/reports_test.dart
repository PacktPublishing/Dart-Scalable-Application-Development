library reports.test;

import 'package:test/test.dart';

import 'package:reports/reports.dart';

void main() {
  group('Report Object', () {
    test('Report ctor', () {
      var rep = new Report('Default');
      expect(rep.title, 'Default');
    });

    test('Report generate empty', () {
      var rep = new Report('Default');
      expect(rep.generate(), true);
      expect(rep.output.length, equals(0));
    });

    test('Report build - Title Only', () {
      var rep = new Report('Default');
      rep.addSection(new Title("Unit Test"));
      expect(rep.allContent.length, equals(1));
    });

    test('Report build - Title and Paragraph', () {
      var rep = new Report('Default');
      rep.addSection(new Title("Unit Test"));
      rep.addSection(new Paragraph("This is a paragraph"));
      expect(rep.allContent.length, equals(2));
    });

    test('Report build - HTML Output', () {
      var rep = new Report('Default');
      rep.addSection(new Title("Unit Test"));
      rep.addSection(new Paragraph("This is a paragraph"));
      expect(rep.generate(), true);
      expect(rep.generatedTimestamp, isNot(null));
      expect("<h1>Unit Test</h1><p>This is a paragraph</p>",
          rep.output.toString());
    });

    test('Report build - Page Break', () {
      var rep = new Report('Sample');
      rep
        ..addSection(new Title("Sample Report"))
        ..addSection(new Paragraph("This is a paragraph"))
        ..addSection(new Pagebreak())
        ..addSection(new Paragraph("This is a paragraph too"));
      expect(rep.generate(), true);
      print(rep.output.toString());
    });
  });
}
