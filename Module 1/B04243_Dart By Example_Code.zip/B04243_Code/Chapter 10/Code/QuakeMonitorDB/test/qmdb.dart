library gupdatetest;

import 'package:test/test.dart';
import 'data.dart';
import '../lib/geoupdate.dart';

void main() {
  
  test('Object create.', () {
    var o = new GeoUpdate("");
    expect(o, isNotNull);
  });
  
  group('GoodJSON', () {
    var o;
    setUp(() { o = new GeoUpdate(sampleJSON);});
    test('T1. Simple load.', () => expect(o.src, equals(sampleJSON)));
    test('T2. Blank load', (){o = new GeoUpdate("");});
  });  
  
  group('BadJSON', () {
    var o;
    test('T1. Truncated.', () { () => expect(o.Features.length, equals(0));});
  });
  
  group('Features', () {
    var o;
    setUp(() {
      o = new GeoUpdate(sampleJSON);
    });      
    test('Test 1', () => expect(o.Features.length, equals(5)));

    test('Test 2', (){
      o.Features.forEach( (feat) => print(feat.toString()) );
    });

    test('Test 3',() {
      o.Features.forEach((feat) => print(feat.geometry));
    });

    test('Test 4', (){
      o.Features.forEach( (feat) => print(feat.toJson()) );
    });

  });
  
}
