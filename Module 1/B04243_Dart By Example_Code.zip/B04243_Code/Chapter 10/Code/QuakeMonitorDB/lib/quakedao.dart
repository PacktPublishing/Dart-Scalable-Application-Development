import 'package:postgresql/postgresql.dart';

import 'package:logging/logging.dart' show Logger, Level, LogRecord;

var uri = 'postgres://webquakeuser:Coco99nut@localhost:5432/quakedata';

class DaoQuake {

  Logger qlog;

  DaoQuake() {
    qlog = new Logger('DataMonitor');
  }

  storeJSON(String json) async {
    var dbconn;
    try {
      dbconn = await connect(uri);
      await dbconn.execute(
          'insert into dm_quakefeed (geojson) values (@geojson)',
          {'geojson': json});

    } catch (exception, stacktrace) {
      qlog.severe("Exception storing JSON.",
                  exception, stacktrace);
      print(exception);
      print(stacktrace);
    } finally {
     dbconn.close();
    }
  }

  displayInfo() async {
    var dbconn;
    try {
      dbconn = await connect(uri);

      var query = """select count(*) as Count,
       min(modified_date) as MinDate,
       max(modified_date) as MaxDate
       from dm_quakefeed
      """;
      var results = await dbconn.query(query).toList();
      print("Count   : ${results[0][0]}");
      print("MinDate : ${results[0][1]}");
      print("MaxDate : ${results[0][2]}");

    } catch (exception, stacktrace) {
      qlog.severe("Exception getting info.", exception, stacktrace);
      print(exception);
    } finally {
      dbconn.close();
    }
  }

  void deleteRecords() async {
    var dbconn;
    try {
      dbconn = await connect(uri);

      var query = "delete from dm_quakefeed";
      await dbconn.execute(query);

      query = "delete from dm_quakefeatures";
      await dbconn.execute(query);

    } catch (exception, stacktrace) {
      qlog.severe("Exception getting info.", exception, stacktrace);
      print(exception);
    } finally {
      dbconn.close();
    }
  }

  storeFeature(String featureID, String json) async {
    var dbconn;
    try {
      dbconn = await connect(uri);

      var query = """select count(*) as Count
       from dm_quakefeatures where qufeat_id ='$featureID'
      """;
      var results = await dbconn.query(query).toList();

      if (results[0][0]!=0)
        return;

      await dbconn.execute(
          'insert into dm_quakefeatures (qufeat_id, geojson) values (@qufeat_id, @geojson)',
          {'qufeat_id': featureID, 'geojson': json});

    } catch (exception, stacktrace) {
      qlog.severe("Exception storing Feature.",
      exception, stacktrace);
      print(exception);
      print(stacktrace);

    } finally {
      dbconn.close();
    }
  }

}
