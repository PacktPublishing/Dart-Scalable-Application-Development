library GeoUpdate;
import 'dart:convert' show JSON;
import 'geofeature.dart';

/// GeoUpdate class.
class GeoUpdate
{
  String src;
  List Features;

  GeoUpdate(String json){
    src = json;
    Features = [];

    if (src.length>0) {

      try
      {
        Map rawjsonobj = JSON.decode(src);

        if (rawjsonobj["features"]!=null) {

          var items = rawjsonobj["features"];

          items.forEach(
              (Map i){
                Features.add(new GeoFeature(i));
              }
          );
        }

      }
      catch(exception)
      {
        print("Error decoding JSON.");
        print("$src");
        print(exception);
      }
    }
  }

}
