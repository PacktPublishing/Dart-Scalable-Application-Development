/// The QuakeMonitorFS library.
library QuakeMonitorFS;

import 'dart:io';
import 'dart:convert';
import 'dart:async';

import 'package:logging/logging.dart' show Logger, Level, LogRecord;

import 'quakedao.dart';
import 'geoupdate.dart';
import 'geofeature.dart';

const String dataUrl =
    "http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson";

const String latestFilename = 'data/latest.txt';

class DataMonitor {

  Logger qlog;
  HttpClient geoClient;
  DaoQuake daoGeoJson;
  int idPreviousFetch = -1;

  DataMonitor() {
    geoClient = new HttpClient();
    qlog = new Logger('DataMonitor');
    daoGeoJson = new DaoQuake();
  }

  fetchData(Timer timerFetch) async {

    try
    {
      qlog.info("Calling web service...");

      HttpClientRequest req = await geoClient.getUrl(Uri.parse(dataUrl));
      HttpClientResponse resp = await req.close();

      await resp.pipe(new File(latestFilename).openWrite());
      String fileContents = await new  File(latestFilename).readAsString();

      var dataset = await JSON.decode(fileContents);

      int newid =  int.parse(dataset['metadata']['generated'].toString());

      if (idPreviousFetch != newid){
        idPreviousFetch = newid;

        //Save to database.
        await daoGeoJson.storeJSON(fileContents);
        qlog.fine("Saved to db $newid - ${fileContents}");

        //Process Features.
        GeoUpdate o = new GeoUpdate(JSON.encode(dataset));

        qlog.fine("Features to process ${o.Features.length}");

        for (int i=0;i<o.Features.length;i++)
        {
          GeoFeature feature = o.Features[i];

          await daoGeoJson.storeFeature(feature.id, feature.toJson());
        }

      }
    }
    catch(exception, stacktrace)
    {
      qlog.severe("Exception fetching JSON.", exception, stacktrace);
      print(exception);
      print(stacktrace);
    }

  }

}
