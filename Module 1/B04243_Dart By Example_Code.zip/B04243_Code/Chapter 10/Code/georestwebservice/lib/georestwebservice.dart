library geoapi;

import 'dart:async';

import 'package:rpc/rpc.dart';
import 'daoapi.dart';
import 'helpers.dart';

@ApiClass(
    name: 'quake',
    version: 'v1',
    description: 'Rest API for Earthquake feature data.')
class Quake {
  @ApiMethod(path: 'hello')
  QuakeResponse hello() {
    return new QuakeResponse()..result = 'Hello world.';
  }

  @ApiMethod(path: 'implementationerror')
  QuakeResponse ImplementationError() {
    throw new Exception();
  }

  @ApiMethod(path: 'latest')
  Future<List<String>> latest() async {
    DaoQuakeAPI quakeAPI = new DaoQuakeAPI();
    return await quakeAPI.fetchTopTenLatest();
  }

  @ApiMethod(path: 'recent/{count}')
  Future<List<String>> recent(String count) async {
    DaoQuakeAPI quakeAPI = new DaoQuakeAPI();
    return await quakeAPI.fetchRecent(int.parse(count));
  }

  @ApiMethod(path: 'record', method: 'POST')
  QuakeResponse recordFeature(QuakeRequest request) {
    DaoQuakeAPI quakeAPI = new DaoQuakeAPI();
    quakeAPI.recordFeature(getFeatureAsJSON(request));

    QuakeResponse quakeResponse = new QuakeResponse();
    quakeResponse.result = "1";

    return quakeResponse;
  }
}
