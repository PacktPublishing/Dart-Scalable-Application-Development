library apihelpers;

import 'package:rpc/rpc.dart';

///Helper response class.
class QuakeResponse {
  @ApiProperty(required: true)
  String result;
}

///Helper Request class.
class QuakeRequest {
  @ApiProperty(required: true)
  int time;

  @ApiProperty(required: true)
  double magnitude;

  @ApiProperty(required: true)
  double longitude;

  @ApiProperty(required: true)
  double latitude;
}

/// JSON Method.
String jsonData =
    '{"properties": {"mag": MAG,"place": "Dart","time": TIME,"type": "earthquake","title": "M MAG - Dartland, Dart."},"geometry": {"type": "Point","coordinates": [LAT,LONG,MAG]}}';

String getFeatureAsJSON(QuakeRequest request) {
  String feature = jsonData;
  feature = feature.replaceAll("MAG", request.magnitude.toString());
  feature = feature.replaceFirst("TIME", request.time.toString());
  feature = feature.replaceFirst("LAT", request.latitude.toString());
  feature = feature.replaceFirst("LONG", request.longitude.toString());
  return feature;
}
