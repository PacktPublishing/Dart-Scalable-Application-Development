import 'package:postgresql/postgresql.dart';
import 'dart:async';

var uri = 'postgres://webquakeuser:Coco99nut@localhost:5432/quakedata';

class DaoQuakeAPI {
  DaoQuake() {}

  Future<List<String>> fetchTopTenLatest() async {
    var dbConn;
    try {
      dbConn = await connect(uri);

      var query = """
      select geojson from dm_quakefeatures order by modified_date desc limit 10
      """;

      List<Row> dbResults = await dbConn.query(query).toList();

      List<String> results = new List<String>();

      dbResults.forEach((record) {
        results.add(record[0]);
      });

      return results;
    } catch (exception, stacktrace) {
      print(exception);
      print(stacktrace);
    } finally {
      dbConn.close();
    }
  }

  Future<List<String>> recordFeature(String json) async {
    var dbConn;
    DateTime time = new DateTime.now();
    String featureID = time.millisecondsSinceEpoch.toString();
    List<String> result = new List<String>();

    try {
      dbConn = await connect(uri);

      await dbConn.execute(
          'insert into dm_quakefeatures (qufeat_id, geojson) values (@qufeat_id, @geojson)',
          {'qufeat_id': featureID, 'geojson': json});
    } catch (exception, stacktrace) {
      print(exception);
      print(stacktrace);
    } finally {
      dbConn.close();
    }
    result.add(featureID);
    return result;
  }

  Future<List<String>> fetchRecent(int count) async {
    var dbConn;
    try {
      dbConn = await connect(uri);

      var query = """
      select geojson from dm_quakefeatures order by modified_date desc limit $count
      """;

      List<Row> dbResults = await dbConn.query(query).toList();

      List<String> results = new List<String>();

      dbResults.forEach((record) {
        results.add(record[0]);
      });

      return results;
    } catch (exception, stacktrace) {
      print(exception);
      print(stacktrace);
    } finally {
      dbConn.close();
    }
  }
}
