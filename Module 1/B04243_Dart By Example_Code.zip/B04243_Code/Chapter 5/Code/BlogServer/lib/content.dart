library content;

const String page404 = """<html>
    <head><title>404 - Not found.</title></head>
    <body>
    <h1>404  - Not found.</h1>
    </body>
    </html>
    """;

const String RobotsTxt = """User-agent: *
Disallow:""";
