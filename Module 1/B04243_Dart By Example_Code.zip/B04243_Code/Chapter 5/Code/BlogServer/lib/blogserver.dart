/// The BlogServer library.
library BlogServer;

import 'dart:io';
import 'package:path/path.dart' as path;

import 'blog.dart';
import 'content.dart';

class BlogServerApp {
  File image;
  Blog hostedBlog;
  var png;

  var BlogTitle = "Greatest Animal Facts Blog";

  BlogServerApp() {
    var srcPath = path.join(Directory.current.path, "content/posts");
    var imgPath = path.join(Directory.current.path, "content/img");
    hostedBlog = new Blog(srcPath, imgPath);
  }

  /// Get request type and process accordingly.
  handleRequest(HttpRequest request) {
    if (request.uri.path.endsWith(".html")) {
      _serveTextFile(request);
    } else if (request.uri.path.endsWith(".png")) {
      _servePngFile(request);
    } else if (request.uri.path == "/robots.txt") {
      _serveRobotsFile(request);
    } else {
      _serve404(request);
    }
  }

  // Serve a Robots.txt File
  void _serveRobotsFile(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.OK
      ..headers.set('Content-Type', 'text/html')
      ..write(RobotsTxt)
      ..close();
  }

  // Serve a 404 if an unknown resource is requested.
  void _serve404(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.NOT_FOUND
      ..headers.set('Content-Type', 'text/html')
      ..write(page404)
      ..close();
  }

  // Serve a PNG file.
  void _servePngFile(HttpRequest request) {
    var imgp = request.uri.path.toString();
    imgp = imgp.replaceFirst(".png", "").replaceFirst("/", "");

    image = hostedBlog.getBlogImage(int.parse(imgp));
    image.readAsBytes().then((raw) {
      request.response
        ..statusCode = HttpStatus.OK
        ..headers.set('Content-Type', 'image/png')
        ..headers.set('Content-Length', raw.length)
        ..add(raw)
        ..close();
    });
  }

  // Serve all text format files.
  void _serveTextFile(HttpRequest request) {
    String content = _getContent(request.uri.path.toString());

    request.response
      ..headers.set('Content-Type', 'text/html')
      ..statusCode = HttpStatus.OK
      ..write("""<html>
      <head><title>$BlogTitle</title></head>
      <body>
      $content
      </body>
      </html>""")
      ..close();
  }

  /// Build the content for the requested path.
  String _getContent(String path) {
    if (path == "/index.html") {
      return hostedBlog.getFrontPage();
    }

    if (path.startsWith("/post")) {
      String idfromUrl =
          path.replaceFirst("/post", "").replaceFirst(".html", "");
      int id = int.parse(idfromUrl);
      return hostedBlog.getBlogPost(id).HTML;
    }

    return "";
  }
}
