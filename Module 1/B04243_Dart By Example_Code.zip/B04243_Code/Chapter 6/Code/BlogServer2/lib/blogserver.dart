library BlogServer;

import 'dart:io';
import 'package:path/path.dart' as path;
import 'package:crypto/crypto.dart';
import 'package:blogserver/blog.dart';
import 'package:blogserver/content.dart';
import 'package:blogserver/log.dart';

/// The BlogServer application object.
class BlogServerApp {
  File image;
  Blog hostedBlog;
  var png;

  var BlogTitle = "Greatest Animal Facts Blog";

  BlogServerApp() {
    var srcPath = path.join(Directory.current.path, "content/posts");
    var imgPath = path.join(Directory.current.path, "content/img");
    hostedBlog = new Blog(srcPath, imgPath);
  }

  /// Get request type and process accordingly.
  handleRequest(HttpRequest request) {
    log(request);

    if (request.method == 'POST') {
      _handleFormPost(request);
    }
    //
    else if (request.uri.path == "/admin") {
      _serveAdminLogin(request);
    } else if (request.uri.path == "/feed.xml") {
      _serveRSSFeed(request);
    }

    //
    else if (request.uri.path.endsWith(".html")) {
      _serveTextFile(request);
    } else if (request.uri.path.endsWith(".json")) {
      _serveJsonFile(request);
    } else if (request.uri.path.endsWith(".png")) {
      _servePngFile(request);
    } else if (request.uri.path == "/robots.txt") {
      _serveRobotsFile(request);
    } else {
      _serve404(request);
    }
  }

  void _serveJsonFile(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.OK
      ..headers.set('Content-Type', 'application/json')
      ..headers.add("Access-Control-Allow-Origin", "*")
      ..headers.add(
          "Access-Control-Allow-Methods", "POST,GET,DELETE,PUT,OPTIONS")
      ..write(hostedBlog.getJSONFeed())
      ..close();
  }

  void _serveRSSFeed(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.OK
      ..headers.set('Content-Type', 'application/rss+xml')
      ..write(hostedBlog.getRSSFeed())
      ..close();
  }

  void _handleFormPost(HttpRequest request) {
    if (request.uri.path == "/login") _performLogin(request);
    if (request.uri.path == "/add") _performNewPost(request);
  }

  void _performNewPost(HttpRequest request) {
    request.listen((List<int> buffer) {
      List formData = _getFormData(buffer);
      String newID = hostedBlog.getNextPostID();
      String filename = "$newID.txt";
      var p = path.join("content", "posts");
      p = path.join(p, filename);

      File postFile = new File(p);
      String post = BlogPost.createBlogPost(formData[0], formData[1]);
      postFile.writeAsStringSync(post);

      hostedBlog.initBlog();

      request.response
        ..statusCode = HttpStatus.OK
        ..headers.set('Content-Type', 'text/html')
        ..redirect(new Uri(path: "post$newID.html"))
        ..close();
    });
  }

  void _performLogin(HttpRequest request) {
    request.listen((List<int> buffer) {
      String page = _checkAdminLogin(buffer);

      request.response
        ..statusCode = HttpStatus.OK
        ..headers.set('Content-Type', 'text/html')
        ..write(page)
        ..close();
    }, onDone: () => request.response.close());
  }

  String _checkAdminLogin(List<int> buffer) {
    var sha = new SHA256();
    sha.add(buffer);
    var digest = sha.close();
    String hex = CryptoUtils.bytesToHex(digest);
    String page = "";

    if (hex != expectedHash) {
      page = wrongPassword;
    } else {
      page = addForm;
    }

    return page;
  }

  List _getFormData(List<int> buffer) {
    var encodedData = new String.fromCharCodes(buffer);
    List pieces = encodedData.split("&");
    List data = [];
    List finalData = [];

    pieces
        .forEach((dateItem) =>
            data.add(dateItem.substring(dateItem.indexOf("=") + 1)));

    data.forEach(
        (encodedItem) => finalData.add(Uri.decodeQueryComponent(encodedItem)));

    return finalData;
  }

  void _serveAdminLogin(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.OK
      ..headers.set('Content-Type', 'text/html')
      ..write(loginForm)
      ..close();
  }

  // Serve a Robots.txt File
  void _serveRobotsFile(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.OK
      ..headers.set('Content-Type', 'text/html')
      ..write(robotsTxt)
      ..close();
  }

  // Serve a 404 if an unknown resource is requested.
  void _serve404(HttpRequest request) {
    request.response
      ..statusCode = HttpStatus.NOT_FOUND
      ..headers.set('Content-Type', 'text/html')
      ..write(page404)
      ..close();
  }

  // Serve a PNG file.
  void _servePngFile(HttpRequest request) {
    var imgPng = request.uri.path.toString();
    imgPng = imgPng.replaceFirst(".png", "").replaceFirst("/", "");

    image = hostedBlog.getBlogImage(int.parse(imgPng));
    image.readAsBytes().then((raw) {
      request.response
        ..statusCode = HttpStatus.OK
        ..headers.set('Content-Type', 'image/png')
        ..headers.set('Content-Length', raw.length)
        ..add(raw)
        ..close();
    });
  }

  // Serve all text format files.
  void _serveTextFile(HttpRequest request) {
    String content = _getContent(request.uri.path.toString());

    request.response
      ..headers.set('Content-Type', 'text/html')
      ..statusCode = HttpStatus.OK
      ..write("""<html>
      <head><title>$BlogTitle</title></head>
      <body>
      $content
      </body>
      </html>""")
      ..close();
  }

  /// Build the content for the requested path.
  String _getContent(String path) {
    if (path == "/index.html") {
      return hostedBlog.getFrontPage();
    } else if (path.endsWith(".json")) {
      return hostedBlog.getJSONFeed();
    } else if (path.endsWith(".xml")) {
      return hostedBlog.getRSSFeed();
    }

    if (path.startsWith("/post")) {
      String idFromUrl =
          path.replaceFirst("/post", "").replaceFirst(".html", "");
      int id = int.parse(idFromUrl);
      if (hostedBlog.IDs.indexOf(id) == -1) id = 1;
      return hostedBlog.getBlogPost(id).HTML;
    }

    return "";
  }
}
