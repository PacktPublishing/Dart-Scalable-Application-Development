library BlogEntities;

import 'dart:io';
import 'dart:math';
import 'dart:convert';

import 'package:path/path.dart' as path;
import 'package:xml/xml.dart';
import 'package:watcher/watcher.dart';

/// Class for a blog website.
class Blog {
  final String _pathPosts;
  final String _pathImgs;
  String _pathDefaultImg;
  List<int> IDs;
  Map<int, String> postPaths;
  Map<int, String> imgPaths;
  Map _cache;
  DirectoryWatcher _changeMonitor;

  Blog(this._pathPosts, this._pathImgs) {
    _changeMonitor = new DirectoryWatcher(this._pathPosts);
    _changeMonitor.events.listen((watchEvent) => initBlog());
  }

  initBlog() async {
    _cache = {};
    IDs = new List<int>();
    postPaths = new Map<int, String>();
    imgPaths = new Map<int, String>();
    await _loadPostList();
    _loadImgList();
  }

  // Load posts for the blog to aid serving.
  _loadPostList() async {
    print("Loading from $_pathPosts");
    Directory blogContent = new Directory(_pathPosts);

    //Load up all the blog posts do get a list of IDs.
    var postsSrc = await blogContent.list();

    await postsSrc.forEach((File f) {
      String postFilename = path.basenameWithoutExtension(f.path);
      int id = int.parse(postFilename);
      IDs.add(id);
      postPaths[id] = f.path;
    });

    IDs.sort();
    IDs = IDs.reversed.toList();
  }

  // Load posts for the img to aid serving.
  void _loadImgList() {
    print("Loading from $_pathImgs");
    Directory imgContent = new Directory(_pathImgs);

    //Load up all the blog posts do get a list of IDs.
    imgContent.list().forEach((File f) {
      String imgFilename = path.basename(f.path).replaceAll(".png", "");
      if (imgFilename != 'default') {
        int id = int.parse(imgFilename);
        imgPaths[id] = f.path;
      } else {
        _pathDefaultImg = f.path;
      }
    });
  }

  // Build a single post the blog.
  BlogPost getBlogPost(int index) {
    if (!_cache.containsKey(index)) {
      _cache[index] = new BlogPost(postPaths[index], index);
    }
    return _cache[index];
  }

  // Build a single post the blog.
  File getBlogImage(int index) {
    String path;
    if (imgPaths.containsKey(index)) {
      path = imgPaths[index];
    } else {
      path = _pathDefaultImg;
    }

    return new File(path);
  }

  // Build the front page of the blog.
  String getFrontPage() {
    String frontPage = "";

    IDs.sublist(0, min(5, IDs.length)).forEach((int postID) {
      BlogPost post = getBlogPost(postID);
      frontPage += post.HTML + "<hr/>";
    });

    return frontPage;
  }
  // Get the next blog posts ID.
  String getNextPostID() {
    return (IDs[0] + 1).toString();
  }

  // Generate JSON feed.
  String getJSONFeed() {
    List posts = new List();

    IDs.forEach((int postID) {
      BlogPost post = getBlogPost(postID);
      Map jsonPost = {};
      jsonPost["id"] = post._id;
      jsonPost["date"] = post._date;
      jsonPost["title"] = post._title;
      jsonPost["url"] = "http://127.0.0.1:8080/post${post._id}.html";
      posts.add(jsonPost);
    });

    return JSON.encode(posts);
  }

  // Generate RSS feed.
  String getRSSFeed() {
    var RssXb = new XmlBuilder();
    RssXb.processing('xml', 'version="1.0"');

    RssXb.element('rss', attributes: {'version': '1.0'}, nest: () {
      RssXb.element('channel', nest: () {
        IDs.forEach((int postID) {
          BlogPost post = getBlogPost(postID);
          RssXb.element('item', nest: () {
            RssXb.element('pubDate', nest: () {
              RssXb.text(post._date);
            });
            RssXb.element('title', nest: () {
              RssXb.text(post._title);
            });
            RssXb.element('link', nest: () {
              RssXb.text("http://127.0.0.1:8080/post${post._id}.html");
            });
          }); //item
        });
      }); //channel
    }); //rss

    var xml = RssXb.build();
    return xml.toXmlString(pretty: true);
  }
}

/// ClassBlog post
class BlogPost {
  List<String> _source;

  int _id;
  String _title;
  String _date;
  String _html;

  get HTML {
    return _html;
  }

  // Load in the blog post;
  BlogPost(String filename, this._id) {
    File postFile = new File(filename);
    _source = postFile.readAsLinesSync();
    process();
  }

  //Create an HTML blog post from the source.
  process() {

    //Extract components.
    _html = "";
    _date = _source[0];
    _title = _source[1];

    //Build.
    _html = "<h2>$_title</h2><b>$_date</b><br/>";
    _html += "<img src=\"$_id.png\" align=\"left\">";
    _source.sublist(2).forEach((line) => _html += line);
    _html += "<br/><a href=\"post$_id.html\">Permalink</a>";
  }

  //
  static String createBlogPost(String Title, String Body) {
    var now = new DateTime.now();
    var postDate = new DateTime(now.year, now.month, now.day);
    var dateOfPost = "${postDate.month}/${postDate.day}/${postDate.year}";
    return "$Title\r\n$dateOfPost\r\n$Body\r\n";
  }
}
