library log;

import 'dart:io';

/// Write an entry to the web access log.
void log(HttpRequest request) {
  String entry = getLogEntry(request);
  File logstore = new File("accesslog.txt");
  logstore.writeAsStringSync(entry, mode: FileMode.APPEND);
}

/// Generate a string of meta-information based on the request.
String getLogEntry(HttpRequest request) {

  //USER_AGENT
  HttpHeaders headers = request.headers;
  String reqUri = "${headers.host},${headers.port}${request.uri.toString()}";
  String entry =
      " ${request.connectionInfo.remoteAddress.address}, $reqUri, ${headers[HttpHeaders.USER_AGENT]}\r\n";

  return (new DateTime.now()).toString() + entry;
}
