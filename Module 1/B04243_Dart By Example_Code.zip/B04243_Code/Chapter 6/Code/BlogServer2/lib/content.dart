library content;

const String page404 = """<html>
    <head><title>404 - Not found.</title></head>
    <body>
    <h1>404  - Not found.</h1>
    </body>
    </html>
    """;

const String robotsTxt = """User-agent: *
Disallow:""";

const String loginForm  = """
<h1>Blog Admin</h1>
<form action="login" method="post">
User:
<input type="text" name="username"/>
<br/>
Pwd:&nbsp;
<input type="password" name="psword"/>
<br/>
<input type="submit" value="Log In"/>
</form>
""";


const String addForm  = """
<h1>Add Blog Entry</h1>
<form action="add" method="post">

<b>Title</b>
<br/>
<input type="text" name="username"/>
<br/>

<b>Entry</b>
<br/>

<textarea type="text" cols="40" Rows="10" name="body">

</textarea>
<br/>
<input type="submit" value="Post"/>
</form>
""";

const String wrongPassword = """
<h1>Login Failed</h1>
""";

const String expectedHash = "bdf252c8385e7c4ae76bca280acd8d44f85d7fdb56f1bfb44f5749ff549ba2f6";