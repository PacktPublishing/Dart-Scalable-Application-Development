import 'dart:html';
import 'dart:async';

import 'lib/canvasmapview.dart';
import 'lib/featureplotter.dart';
import 'lib/mapindicator.dart';

const int width = 800;
const int height = 600;
bool zoomed = false;

MapDisplay quakeMap = null;
FeaturePlotter featPlotter = null;

/// Draw the initial map and kick off the update Timers.
main() async {
  quakeMap = new MapDisplay(querySelector('#mapview'), width, height);
  await quakeMap.loadImage();

  featPlotter = new FeaturePlotter(width, height, quakeMap.mapCtx);

  quakeMap.showPopup = showPopup;
  quakeUpdate();

  querySelector('#zoombtn').onClick.listen(zoomMap);
  querySelector('#locatebtn').onClick.listen(locateUser);
  querySelector('#sortbtn').onClick.listen(sortFeatures);

  new Timer.periodic(new Duration(seconds: 60), quakeUpdate);
  new Timer.periodic(new Duration(milliseconds: 100), animationUpdate);
}

/// Draw the next animation step.
void animationUpdate([Timer t = null]) {
  featPlotter.updateDisplay();
}

/// Update data feed.
quakeUpdate([Timer t = null]) async {
  await featPlotter.updateData();
  featPlotter.updateHotspots();
  quakeMap.drawMapGrid();

  List notiFeature =
      featPlotter.geoFeatures.lastWhere((List gf) => gf[2] > 1.9);

  String permResult = await Notification.requestPermission();
  if (permResult == 'granted') {
    Notification notifyQuake = new Notification('Quake Alert',
        body: 'Quake Update ${notiFeature[3]} - ${notiFeature[2]}');
  }
}

/// Display a Popup if over map indicator.
void showPopup(int x, int y) {
  bool inHotspot = false;

  if (zoomed) {
    x = x ~/ 2;
    y = y ~/ 2;
  }

  featPlotter.hotspotInfo.forEach((Rectangle<int> key, String value) {
    if (key.containsPoint(new Point(x, y))) {
      inHotspot = true;
      querySelector('#popup').innerHtml = value;
    }
  });

  if (inHotspot) querySelector('#popup').style.visibility = "visible";
}

/// Zoom in the map.
zoomMap(Event evt) async {
  if (zoomed == true) {
    zoomed = false;
    quakeMap.mapCtx.resetTransform();
    quakeMap.mapCtx.scale(1, 1);
  } else {
    zoomed = true;
    quakeMap.mapCtx.scale(2, 2);
  }
  quakeMap.drawMapGrid();
}

/// Locate the user on the map.
locateUser(Event evt) async {
  Geoposition geoPos = await window.navigator.geolocation.getCurrentPosition();
  MapIndicator mapIndicator;
  var pos =
      featPlotter.toPoint(geoPos.coords.longitude, geoPos.coords.latitude);
  mapIndicator = new MapIndicator(pos.x, pos.y, quakeMap.mapCtx, 4);
  mapIndicator.colorPrimary = "#0000ff";
  mapIndicator.colorSecondary = "#00ffff";
  featPlotter.userLocation.add(mapIndicator);
}

/// Display a list of the features sorted by depth.
void sortFeatures(Event evt) {
  featPlotter.sortFeatures();
  DivElement out = querySelector('#depthDetail');
  out.nodes.clear();
  featPlotter.geoFeatures.forEach((feature) {
    LIElement detail = new LIElement();
    detail.innerHtml = "${feature[5]}km - ${feature[3]}";
    out.nodes.add(detail);
  });
}
