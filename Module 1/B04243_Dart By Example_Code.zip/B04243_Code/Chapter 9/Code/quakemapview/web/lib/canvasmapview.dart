library cancasmapview;

import 'dart:html';
import 'dart:async';

/// Map view of the quake data.
class MapDisplay {
  int width = 0;
  int height = 0;
  CanvasRenderingContext2D mapCtx;
  ImageElement mapImage;

  Function showPopup;

  MapDisplay(CanvasElement mapCanvas, this.width, this.height) {
    mapCtx = mapCanvas.getContext("2d");
    mapCanvas.onMouseMove.listen(mouseMove);
  }

  ///Load the background image.
  Future loadImage() async {
    mapImage = new ImageElement(src: "map.png");
    return mapImage.onLoad.first;
  }

  ///Draw map and axis lines.
  void drawMapGrid() {
    mapCtx
      ..drawImageScaled(mapImage, 0, 0, 800, 600)
      ..fillStyle = "#FF0000"
      ..strokeStyle = "rgba(255,0,0,64)"
      ..moveTo(width / 2, 0)
      ..lineTo(width / 2, height)
      ..stroke()
      ..moveTo(0, height / 2)
      ..lineTo(width, height / 2)
      ..stroke();
  }

  ///Mouse movement handler.
  void mouseMove(MouseEvent e) {
    if (showPopup != null) showPopup(e.client.x - 50, e.client.y - 90);
  }
}
