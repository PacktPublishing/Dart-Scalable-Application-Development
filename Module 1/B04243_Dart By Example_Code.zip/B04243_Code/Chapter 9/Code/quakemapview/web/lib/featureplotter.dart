library featureplotter;

import 'dart:html';
import 'dart:math';
import 'dart:convert';
import 'mapindicator.dart';

const String jsonSrc = "http://127.0.0.1:8080/api/quake/v1/latest";

/// This class arranges the indicators on the map.
class FeaturePlotter {
  int width = 0;
  int height = 0;

  List geoFeatures;
  List<MapIndicator> mapIndicators;
  List<MapIndicator> userLocation;
  Map<Rectangle<int>, String> hotspotInfo;
  CanvasRenderingContext2D ctx;

  /// Set up the main lists.
  FeaturePlotter(this.width, this.height, this.ctx) {
    geoFeatures = new List();
    mapIndicators = new List<MapIndicator>();
    userLocation = new List<MapIndicator>();
    hotspotInfo = new Map<Rectangle<int>, String>();
  }

  /// Update the map indicators on the screen.
  void updateDisplay() {
    mapIndicators.forEach((mapIndicator) => mapIndicator.update());
    userLocation.forEach((mapIndicator) => mapIndicator.update());
  }

  /// Update the geo features list.
  fetchFeatureList() async {
    geoFeatures.clear();

    String data = await HttpRequest.getString(jsonSrc);
    List items;
    List quakePoints = [];

    try {
      items = JSON.decode(data);
    } catch (exception, stacktrace) {
      print(exception);
      print(stacktrace);
    }

    if (items != null) {
      items.forEach((String post) {
        Map feature = JSON.decode(post);

        List quakedata = [
          feature['geometry']['coordinates'][0],
          feature['geometry']['coordinates'][1],
          feature['properties']['mag'],
          feature['properties']['place'],
          feature['properties']['type'],
          feature['geometry']['coordinates'][2]
        ];

        quakePoints.add(quakedata);
      });

      quakePoints.where((qp) => qp[4] == 'earthquake').forEach((qp) {
        geoFeatures.add(qp);
      });
    }
  }

  /// Update the Data and create indicators.
  updateData() async {
    await fetchFeatureList();
    mapIndicators.clear();
    geoFeatures.forEach((List feature) {
      Point pos = toPoint(feature[0], feature[1]);
      MapIndicator mi;
      mi = new MapIndicator(pos.x, pos.y, ctx, feature[2].toInt());
      mi.summary = "Magnitude ${feature[2]} - ${feature[3]}.";
      mapIndicators.add(mi);
    });
  }

  /// Update the Hotspots list for the new mapIndicators.
  void updateHotspots() {
    hotspotInfo.clear();
    mapIndicators.forEach((MapIndicator mi) {
      Rectangle<int> rect = new Rectangle(mi.x - mi.maxWidth,
          mi.y - mi.maxWidth, mi.maxWidth * 2, mi.maxWidth * 2);

      hotspotInfo[rect] = mi.summary;
    });
  }

  /// Convert longitude and latitude to XY for the map.
  Point toPoint(double longitude, double latitude) {
    double x = 0.0;
    double y = 0.0;
    double hdeg = width.toDouble() / 360;
    double vdeg = height.toDouble() / 180;

    x = (width / 2) + (hdeg * longitude);
    y = (height / 2) - (vdeg * latitude);

    return new Point(x.toInt(), y.toInt());
  }

  /// Sort the list of features according to depth.
  List sortFeatures() {
    geoFeatures.sort((a, b) => a[5] - b[5]);
    return geoFeatures;
  }
}
