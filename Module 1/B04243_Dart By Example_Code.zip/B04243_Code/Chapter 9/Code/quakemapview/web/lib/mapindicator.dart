library mapindicator;

import 'dart:html';
import 'dart:math';

///Map Indicator class.
class MapIndicator {
  int x = 0;
  int y = 0;
  int width = 1;
  int magnitude = 0;
  int maxWidth = 0;
  String summary = "";

  CanvasRenderingContext2D ctx = null;
  String colorPrimary = "#FF00FF";
  String colorSecondary = "#FF0000";

  ///Create the indicator.
  MapIndicator(this.x, this.y, this.ctx, this.magnitude) {
    maxWidth = (width + 1) + magnitude * 2;
  }

  ///Update the indicator and draw the display
  void update() {
    width++;
    if (width == maxWidth) width = 0;
    draw();
  }

  ///Draw the map indicator with the current width.
  void draw() {
    ctx
      ..beginPath()
      ..arc(x, y, width, 0, 2 * PI, false)
      ..fillStyle = colorPrimary
      ..fill()
      ..lineWidth = 1
      ..strokeStyle = colorSecondary
      ..stroke();
  }
}
