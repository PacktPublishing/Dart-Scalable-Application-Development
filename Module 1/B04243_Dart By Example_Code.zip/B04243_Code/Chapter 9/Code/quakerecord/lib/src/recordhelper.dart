library quakerecord.helper;

/// A helper class to deal with quake feature settings.
class ProcessHelper {

  ///Swaps the data structure.
  void reversePolar() {}
}
