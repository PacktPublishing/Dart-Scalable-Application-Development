library quakerecord.base;

/// A lightweight object to process a raw earthquake feature.
///
/// * Must have valid JSON.
/// * Must be less than 128MB.
///
class Processor {

  // Store for the JSON.
  String _feature;

  /// The state of processing
  bool get processed => true;

  /// The default constructor.
  ///     Processor processor;
  ///     processor = new Processor('{}');
  Processor(String feature) {}

  /// Returns a converted object based on the feature passed into
  /// the constructor [Processor].
  object convert() {
    // A normal comment.
    return new Object();
  }

  /// Changes feature based on partial data.
  /// *BETA QUALITY*
  ///
  /// 1. Estimates end points.
  /// 2. Transforms polarity.
  ///
  void experimentalNewMethod() {}
}
