/// The quakerecord library for interfacing with legacy systems.
///
/// This is a library for a detail record of quake features.
///
library quakerecord;

export 'src/quakerecord_base.dart';
