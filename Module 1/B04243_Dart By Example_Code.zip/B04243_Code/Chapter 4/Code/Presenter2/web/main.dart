import 'package:presenter/slideshowapp.dart';

void main() {
  new SlideShowApp();
}

