/**
 * DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
 * This is a library that provides messages for a es locale. All the
 * messages from the main program should be duplicated here with the same
 * function name.
 */

library messages_es;
import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

class MessageLookup extends MessageLookupByLibrary {

  get localeName => 'es';
  static btnDemo() => "Manifestación";

  static btnEndShow() => "Fin de la presentación ";

  static btnFirstSlide() => "Primero";

  static btnHandouts() => "Folleto";

  static btnInsertDate() => "Insertar";

  static btnLastSlide() => "Último";

  static btnNextSlide() => "Siguiente";

  static btnOverview() => "Visión de conjunto";

  static btnPrevSlide() => "Anterior";

  static btnStartShow() => "Inicio Mostrar";

  static btnTimer() => "Iniciar / detener";

  static lblPageColor() => "Fondo de página";


  final messages = const {
    "btnDemo" : btnDemo,
    "btnEndShow" : btnEndShow,
    "btnFirstSlide" : btnFirstSlide,
    "btnHandouts" : btnHandouts,
    "btnInsertDate" : btnInsertDate,
    "btnLastSlide" : btnLastSlide,
    "btnNextSlide" : btnNextSlide,
    "btnOverview" : btnOverview,
    "btnPrevSlide" : btnPrevSlide,
    "btnStartShow" : btnStartShow,
    "btnTimer" : btnTimer,
    "lblPageColor" : lblPageColor
  };
}