/**
 * DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
 * This is a library that provides messages for a fr locale. All the
 * messages from the main program should be duplicated here with the same
 * function name.
 */

library messages_fr;
import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

class MessageLookup extends MessageLookupByLibrary {

  get localeName => 'fr';
  static btnDemo() => "Démo";

  static btnEndShow() => "Fin Montrer";

  static btnFirstSlide() => "Première";

  static btnHandouts() => "Polycopié";

  static btnInsertDate() => "Insérer";

  static btnLastSlide() => "Dernier";

  static btnNextSlide() => "Suivant";

  static btnOverview() => "Vue d\'ensemble";

  static btnPrevSlide() => "Précédent";

  static btnStartShow() => "Démarrer Montrer";

  static btnTimer() => "Commencer Arrêter";

  static lblPageColor() => "Fond de page";


  final messages = const {
    "btnDemo" : btnDemo,
    "btnEndShow" : btnEndShow,
    "btnFirstSlide" : btnFirstSlide,
    "btnHandouts" : btnHandouts,
    "btnInsertDate" : btnInsertDate,
    "btnLastSlide" : btnLastSlide,
    "btnNextSlide" : btnNextSlide,
    "btnOverview" : btnOverview,
    "btnPrevSlide" : btnPrevSlide,
    "btnStartShow" : btnStartShow,
    "btnTimer" : btnTimer,
    "lblPageColor" : lblPageColor
  };
}