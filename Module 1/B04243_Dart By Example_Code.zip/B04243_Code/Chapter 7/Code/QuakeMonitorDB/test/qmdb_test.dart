library gupdatetest;

import 'package:test/test.dart';
import 'data.dart';

void main() {
  test('Object create.', () {
    var o = new GeoUpdate();
    expect(o, isNotNull);
  });

  group('GoodJSON', () {
    var o;
    setUp(() {
      o = new GeoUpdate(sampleJson);
    });
    test('T1. Simple load.', () => expect(o.src, equals(sampleJson)));
    test('T2. Blank load', () {
      o = new GeoUpdate("");
    });
  });

  group('BadJSON', () {
    var o;
    test('T1. Truncated.', () {
      o = new GeoUpdate(sampleBad);
    });
  });

  group('Features', () {
    var o;
    setUp(() {
      o = new GeoUpdate(sampleJson);
    });
    test('Test 1', () => expect(o.features.length, equals(5)));
    test('Test 2', () => expect(1, equals(1)));
  });
}
