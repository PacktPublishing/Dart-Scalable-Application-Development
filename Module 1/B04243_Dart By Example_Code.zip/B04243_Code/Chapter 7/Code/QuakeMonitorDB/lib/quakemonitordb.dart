/// The QuakeMonitorFS library.
library QuakeMonitorFS;

import 'dart:io';
import 'dart:convert';
import 'dart:async';

import 'package:logging/logging.dart' show Logger, Level, LogRecord;

import 'quakedao.dart';

const String dataUrl =
    "http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson";

const String latestFilename = 'data/latest.txt';

class DataMonitor {
  Logger log;
  HttpClient geoClient;
  DaoQuake daoGeoJson;
  int idPreviousFetch = -1;

  DataMonitor() {
    geoClient = new HttpClient();
    log = new Logger('DataMonitor');
    daoGeoJson = new DaoQuake();
  }

  fetchData(Timer timerFetch) async {
    try {
      log.info("Calling web service...");
      HttpClientRequest req = await geoClient.getUrl(Uri.parse(dataUrl));
      HttpClientResponse resp = await req.close();

      await resp.pipe(new File(latestFilename).openWrite());
      String fileContents = await new File(latestFilename).readAsString();

      var dataset = await JSON.decode(fileContents);

      int newId = int.parse(dataset['metadata']['generated'].toString());

      if (idPreviousFetch != newId) {
        idPreviousFetch = newId;

        //Save to database.
        await daoGeoJson.storeJson(dataset.toString());

        log.fine("Saved to db $newId - ${dataset.toString()}");
      }
    } catch (exception, stacktrace) {
      log.severe("Exception fetching JSON.", exception, stacktrace);
      print(exception);
      print(stacktrace);
    }
  }
}
