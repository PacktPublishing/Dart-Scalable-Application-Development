import 'package:postgresql/postgresql.dart';
import 'package:logging/logging.dart' show Logger, Level, LogRecord;

String uri = 'postgres://webquakeuser:Coco99nut@localhost:5432/quakedata';

class DaoQuake {
  Logger log;

  DaoQuake() {
    log = new Logger('DataMonitor');
  }

  storeJson(String jsonString) async {
    var dbConn;
    try {
      dbConn = await connect(uri);
      await dbConn.execute(
          'insert into dm_quakefeed (geojson) values (@geojson)', {
        'geojson': jsonString
      });
    } catch (exception, stacktrace) {
      log.severe("Exception storing JSON.", exception, stacktrace);
      print(exception);
      print(stacktrace);
    } finally {
      dbConn.close();
    }
  }

  displayInfo() async {
    var dbConn;
    try {
      dbConn = await connect(uri);

      var query = """select count(*) as Count,
       min(modified_date) as MinDate,
       max(modified_date) as MaxDate
       from dm_quakefeed
      """;
      var results = await dbConn.query(query).toList();
      print("Count   : ${results[0][0]}");
      print("MinDate : ${results[0][1]}");
      print("MaxDate : ${results[0][2]}");
    } catch (exception, stacktrace) {
      log.severe("Exception getting info.", exception, stacktrace);
      print(exception);
    } finally {
      dbConn.close();
    }
  }

  deleteRecords() async {
    var dbConn;
    try {
      dbConn = await connect(uri);

      var query = "delete from dm_quakefeed";
      await dbConn.execute(query);
    } catch (exception, stacktrace) {
      log.severe("Exception getting info.", exception, stacktrace);
      print(exception);
    } finally {
      dbConn.close();
    }
  }
}
