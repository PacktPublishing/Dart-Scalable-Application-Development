/// The QuakeMonitorFS library.
library QuakeMonitorFS;

import 'dart:io';
import 'dart:convert';
import 'dart:async';

import 'package:path/path.dart' as path;
import 'package:logging/logging.dart' show Logger, Level, LogRecord;

const String dataUrl =
    "http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson";

const String latestFilename = 'latest.txt';

class DataMonitor {
  Logger log;
  HttpClient geoClient;
  int idPreviousFetch = -1;

  DataMonitor() {
    geoClient = new HttpClient();
    log = new Logger('DataMonitor');
  }

  fetchData(Timer timerFetch) async {
    try {
      var outDir = new Directory('data');
      if (!await outDir.exists()) {
        outDir.create();
      }

      log.info("Calling web service...");
      HttpClientRequest req = await geoClient.getUrl(Uri.parse(dataUrl));
      HttpClientResponse resp = await req.close();
      String latestFilePath = path.join('data', latestFilename);
      await resp.pipe(new File(latestFilePath).openWrite());
      String fileContents = await new File(latestFilePath).readAsString();

      var dataset = await JSON.decode(fileContents);

      int newId = int.parse(dataset['metadata']['generated'].toString());

      if (idPreviousFetch != newId) {
        idPreviousFetch = newId;
        var f = new File(path.join('data', '${newId}.txt'));
        await f.writeAsString(dataset.toString());
        log.fine("Saved $newId - ${dataset.toString()}");
      }
    } catch (exception, stacktrace) {
      log.severe("Exception fetching JSON.", exception, stacktrace);
    }
  }
}
