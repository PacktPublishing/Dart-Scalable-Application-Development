library QuakeMonitorFS.test;

import 'package:test/test.dart';

//import 'package:QuakeMonitorFS/quakemonitorfs.dart';

void main() {
  test('calculate', () {
    expect(43, 42);
  });
}
