﻿CREATE TABLE dm_quakefeed (
	quake_id serial PRIMARY KEY,
	geojson text NOT NULL,
	modified_date TIMESTAMP default CURRENT_TIMESTAMP
	);