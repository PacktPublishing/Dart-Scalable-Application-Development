Chapter no	Code present
1	         YES
2	         YES
3	         YES
4	         YES
5	         YES
6	         YES
7	         YES
8	         YES
9	         YES
