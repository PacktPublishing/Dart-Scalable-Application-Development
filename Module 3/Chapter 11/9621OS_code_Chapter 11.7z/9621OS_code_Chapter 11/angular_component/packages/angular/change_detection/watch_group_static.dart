library watch_group_static;

import 'package:angular/change_detection/watch_group.dart';

