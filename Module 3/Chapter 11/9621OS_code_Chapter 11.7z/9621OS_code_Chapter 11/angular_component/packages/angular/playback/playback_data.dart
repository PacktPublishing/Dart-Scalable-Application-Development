library angular.playback.playback_data;

// During HTTP playback, this file will be replaced with a file
// that has playback data.

var playbackData = {};
