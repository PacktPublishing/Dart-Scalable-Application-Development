library angular.core.registry;

abstract class MetadataExtractor {
  Iterable call(Type type);
}
